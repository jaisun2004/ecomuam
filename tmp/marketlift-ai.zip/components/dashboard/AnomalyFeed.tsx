
import React from 'react';
import { recentAlerts } from '../../data/mockData';
import { BellIcon } from '../icons/ModuleIcons';

const AnomalyFeed: React.FC = () => {
  return (
    <div className="bg-brand-medium w-full lg:w-80 border-l border-brand-light flex flex-col h-full">
      <div className="p-4 border-b border-brand-light flex items-center space-x-2">
        <BellIcon className="h-5 w-5 text-brand-accent" />
        <h3 className="font-bold text-white">Live Anomaly Feed</h3>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {recentAlerts.map((alert) => (
          <div key={alert.id} className="bg-brand-dark p-3 rounded-lg border border-brand-light shadow-sm hover:border-brand-accent transition-colors cursor-pointer group">
            <div className="flex justify-between items-start mb-1">
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                    alert.severity === 'critical' ? 'bg-red-500 text-white' :
                    alert.severity === 'warning' ? 'bg-amber-500 text-brand-dark' :
                    'bg-blue-500 text-white'
                }`}>
                    {alert.severity}
                </span>
                <span className="text-xs text-gray-500">{alert.timestamp}</span>
            </div>
            <p className="text-xs text-brand-accent font-semibold mb-1">{alert.module}</p>
            <p className="text-sm text-gray-300 leading-snug group-hover:text-white transition-colors">
                {alert.message}
            </p>
          </div>
        ))}
        <button className="w-full py-2 text-xs text-gray-400 hover:text-white border border-dashed border-gray-600 rounded mt-4">
            View All Alerts
        </button>
      </div>
    </div>
  );
};

export default AnomalyFeed;
