
import React, { useState, useEffect } from 'react';
import { Module } from '../../types';
import { CloseIcon, TableCellsIcon, ArrowDownTrayIcon, FilterIcon, DocumentPlusIcon } from '../icons/ModuleIcons';
import { AssortmentVisual, ShareOfShelfVisuals, ScatterPlot, SimpleBarChart } from '../shared/Visuals';

interface AnalyticalDashboardProps {
  activeModule: Module;
  onClose: () => void;
}

// Helper types for dynamic configuration
interface Column {
  id: string;
  label: string;
}
interface RowData {
    [key: string]: string | number;
    impact?: 'positive' | 'negative' | 'neutral';
}
interface ModuleConfig {
    kpis: { label: string; value: string; change: string; changeColor: string; }[];
    columns: Column[];
    data: RowData[];
    chartSection: React.ReactNode;
}

const AnalyticalDashboard: React.FC<AnalyticalDashboardProps> = ({ activeModule, onClose }) => {
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isReportBuilderOpen, setIsReportBuilderOpen] = useState(false);
  const [isRewriteOpen, setIsRewriteOpen] = useState(false);
  const [rewriteData, setRewriteData] = useState<{sku: string, title: string, description: string} | null>(null);
  
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [config, setConfig] = useState<ModuleConfig | null>(null);

  useEffect(() => {
      const newConfig = getModuleConfig(activeModule.id);
      setConfig(newConfig);
      setSelectedColumns(newConfig.columns.map(c => c.id));
  }, [activeModule.id]);

  const toggleColumn = (id: string) => {
    if (selectedColumns.includes(id)) {
      setSelectedColumns(selectedColumns.filter(c => c !== id));
    } else {
      setSelectedColumns([...selectedColumns, id]);
    }
  };

  // Dynamic Configuration Generator based on Module ID
  const getModuleConfig = (id: string): ModuleConfig => {
      switch(id) {
          case 'availability':
              return {
                  kpis: [
                      { label: 'Avg OOS Rate', value: '8.4%', change: '↑ 1.2%', changeColor: 'text-red-400' },
                      { label: 'Lost Revenue (Est)', value: '₹66L', change: '↑ 5%', changeColor: 'text-red-400' },
                      { label: 'Fulfillment Rate', value: '91.6%', change: '↓ 1.2%', changeColor: 'text-amber-400' },
                      { label: 'Restock TAT', value: '1.8 Days', change: 'Stable', changeColor: 'text-gray-400' },
                  ],
                  columns: [
                      { id: 'sku', label: 'SKU Name' },
                      { id: 'retailer', label: 'Retailer' },
                      { id: 'city', label: 'Location' },
                      { id: 'status', label: 'Stock Status' },
                      { id: 'days_supply', label: 'Days of Supply' },
                      { id: 'lost_rev', label: 'Lost Revenue' },
                  ],
                  data: [
                      { sku: 'SuperBoost Energy', retailer: 'Blinkit', city: 'Delhi', status: 'OOS', days_supply: 0, lost_rev: '₹12,000', impact: 'negative' },
                      { sku: 'SuperBoost Energy', retailer: 'Zepto', city: 'Mumbai', status: 'Low Stock', days_supply: 2, lost_rev: '₹4,500', impact: 'negative' },
                      { sku: 'Pro-Hydrate', retailer: 'Amazon', city: 'National', status: 'In Stock', days_supply: 15, lost_rev: '₹0', impact: 'positive' },
                      { sku: 'Organic Tea', retailer: 'Swiggy', city: 'Bangalore', status: 'OOS', days_supply: 0, lost_rev: '₹8,200', impact: 'negative' },
                  ],
                  chartSection: (
                      <div className="space-y-6">
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                              <div className="bg-brand-dark p-4 rounded border border-brand-light">
                                  <h4 className="text-sm font-bold text-gray-300 mb-4">OOS Trend by Hour (Last 24h)</h4>
                                  <div className="h-48 flex items-end space-x-1">
                                      {[...Array(24)].map((_, i) => (
                                          <div key={i} className="flex-1 bg-red-500/50 hover:bg-red-500 transition-colors" style={{ height: `${Math.random() * 80 + 10}%` }}></div>
                                      ))}
                                  </div>
                                  <div className="flex justify-between text-xs text-gray-500 mt-2"><span>00:00</span><span>12:00</span><span>23:00</span></div>
                              </div>
                              <div className="bg-brand-dark p-4 rounded border border-brand-light">
                                  <h4 className="text-sm font-bold text-gray-300 mb-4">Availability by Retailer</h4>
                                  <div className="space-y-3">
                                      {[{l: 'Amazon', v: 98, c: 'bg-green-500'}, {l: 'Blinkit', v: 82, c: 'bg-red-500'}, {l: 'Zepto', v: 91, c: 'bg-amber-500'}, {l: 'Swiggy', v: 88, c: 'bg-amber-500'}].map((d) => (
                                          <div key={d.l} className="flex items-center text-xs">
                                              <span className="w-16 text-gray-400">{d.l}</span>
                                              <div className="flex-1 bg-gray-700 h-2 rounded overflow-hidden">
                                                  <div className={`h-full ${d.c}`} style={{ width: `${d.v}%`}}></div>
                                              </div>
                                              <span className="w-8 text-right font-bold text-gray-300">{d.v}%</span>
                                          </div>
                                      ))}
                                  </div>
                              </div>
                          </div>
                          
                          <div className="bg-brand-dark p-6 rounded-xl border border-brand-light">
                              <div className="flex items-center justify-between mb-6">
                                  <h4 className="text-lg font-bold text-white">Category Assortment Deep Dive</h4>
                                  <span className="px-3 py-1 bg-brand-accent/20 text-brand-accent text-[10px] font-bold rounded-full uppercase">Category: Energy Drinks</span>
                              </div>
                              <AssortmentVisual />
                          </div>
                      </div>
                  )
              };

          case 'pricing':
              return {
                  kpis: [
                      { label: 'Price Index', value: '103.2', change: '↑ 2pts', changeColor: 'text-amber-400' },
                      { label: 'Buy Box Win %', value: '82%', change: '↓ 5%', changeColor: 'text-red-400' },
                      { label: 'Promo Intensity', value: 'High', change: 'Market-wide', changeColor: 'text-gray-400' },
                      { label: 'Violations', value: '12', change: '+3', changeColor: 'text-red-400' },
                  ],
                  columns: [
                      { id: 'sku', label: 'SKU Name' },
                      { id: 'retailer', label: 'Retailer' },
                      { id: 'my_price', label: 'Our Price' },
                      { id: 'comp_price', label: 'Comp Price' },
                      { id: 'index', label: 'Price Index' },
                      { id: 'violation', label: 'Violation?' },
                  ],
                  data: [
                      { sku: 'SuperBoost Energy', retailer: 'Amazon', my_price: '₹120', comp_price: '₹110', index: 109, violation: 'No', impact: 'neutral' },
                      { sku: 'SuperBoost Energy', retailer: 'Blinkit', my_price: '₹125', comp_price: '₹105', index: 119, violation: 'Yes', impact: 'negative' },
                      { sku: 'Pro-Hydrate', retailer: 'Zepto', my_price: '₹250', comp_price: '₹250', index: 100, violation: 'No', impact: 'positive' },
                  ],
                  chartSection: (
                       <div className="space-y-6">
                           <div className="bg-brand-dark p-4 rounded border border-brand-light">
                              <h4 className="text-sm font-bold text-gray-300 mb-4">Price Trend vs Market Leader</h4>
                               <div className="h-48 w-full relative">
                                   <svg className="w-full h-full overflow-visible" preserveAspectRatio="none">
                                       <polyline points="0,100 50,90 100,95 150,60 200,60 250,50 300,55" fill="none" stroke="#3b82f6" strokeWidth="2" />
                                       <polyline points="0,80 50,85 100,70 150,90 200,85 250,95 300,100" fill="none" stroke="#ef4444" strokeWidth="2" strokeDasharray="4" />
                                   </svg>
                                   <div className="absolute top-0 right-0 p-2 bg-brand-medium/80 rounded text-xs border border-brand-light">
                                       <div className="flex items-center"><span className="w-2 h-2 bg-blue-500 rounded mr-1"></span> Us</div>
                                       <div className="flex items-center"><span className="w-2 h-2 bg-red-500 rounded mr-1"></span> Competitor</div>
                                   </div>
                               </div>
                           </div>

                           <div className="bg-brand-dark p-6 rounded-xl border border-brand-light">
                               <div className="flex items-center justify-between mb-6">
                                   <h4 className="text-lg font-bold text-white">Category Assortment Deep Dive</h4>
                                   <span className="px-3 py-1 bg-brand-accent/20 text-brand-accent text-[10px] font-bold rounded-full uppercase">Category: Energy Drinks</span>
                               </div>
                               <AssortmentVisual />
                           </div>
                       </div>
                  )
              };

          case 'share-of-shelf':
              return {
                  kpis: [
                      { label: 'Avg Organic Rank', value: '#5.2', change: '↓ 1.1', changeColor: 'text-red-400' },
                      { label: 'Share of Voice', value: '18%', change: '↑ 2%', changeColor: 'text-green-400' },
                      { label: 'Sponsored Rank', value: '#2.1', change: 'Stable', changeColor: 'text-gray-400' },
                      { label: 'Top 3 Share', value: '45%', change: '↑ 5%', changeColor: 'text-green-400' },
                  ],
                  columns: [
                      { id: 'keyword', label: 'Keyword' },
                      { id: 'vol', label: 'Search Vol' },
                      { id: 'org_rank', label: 'Org Rank' },
                      { id: 'sponsor_rank', label: 'Sponsor Rank' },
                      { id: 'sov', label: 'SOV %' },
                  ],
                  data: [
                      { keyword: 'Energy Drink', vol: 'High', org_rank: 4, sponsor_rank: 1, sov: '25%', impact: 'positive' },
                      { keyword: 'Sugar Free Drink', vol: 'Med', org_rank: 12, sponsor_rank: 4, sov: '5%', impact: 'negative' },
                      { keyword: 'Electrolytes', vol: 'High', org_rank: 2, sponsor_rank: 2, sov: '30%', impact: 'positive' },
                  ],
                  chartSection: (
                      <div className="bg-brand-dark p-6 rounded-xl border border-brand-light">
                          <h4 className="text-lg font-bold text-white mb-6">Share of Shelf Analysis</h4>
                          <ShareOfShelfVisuals />
                      </div>
                  )
              };

            case 'content-audit':
                return {
                    kpis: [
                        { label: 'Avg Content Score', value: '72/100', change: 'Stable', changeColor: 'text-gray-400' },
                        { label: 'Title Compliance', value: '64%', change: '↓ 2%', changeColor: 'text-amber-400' },
                        { label: 'Image Compliance', value: '88%', change: '↑ 5%', changeColor: 'text-green-400' },
                        { label: 'Avg Rating', value: '4.2', change: '↑ 0.1', changeColor: 'text-green-400' },
                    ],
                    columns: [
                        { id: 'sku', label: 'SKU' },
                        { id: 'retailer', label: 'Retailer' },
                        { id: 'score', label: 'Total Score' },
                        { id: 'title', label: 'Title Check' },
                        { id: 'images', label: 'Image Check' },
                        { id: 'reviews', label: 'Review Count' },
                        { id: 'action', label: 'Action' },
                    ],
                    data: [
                        { sku: 'SKU-101', retailer: 'Amazon', score: 65, title: 'Fail', images: 'Pass', reviews: 1540, impact: 'negative', action: 'Rewrite' },
                        { sku: 'SKU-101', retailer: 'Blinkit', score: 88, title: 'Pass', images: 'Pass', reviews: 120, impact: 'positive', action: 'View' },
                        { sku: 'SKU-300', retailer: 'Zepto', score: 52, title: 'Fail', images: 'Fail', reviews: 45, impact: 'negative', action: 'Rewrite' },
                    ],
                    chartSection: (
                        <div className="grid grid-cols-2 gap-4">
                             <div className="bg-brand-dark p-4 rounded border border-brand-light">
                                 <h4 className="text-sm font-bold text-gray-300 mb-2">Score Distribution</h4>
                                 <div className="flex items-center space-x-2">
                                     <span className="text-xs w-8 text-gray-400">Poor</span>
                                     <div className="flex-1 h-2 bg-gray-700 rounded"><div className="w-[20%] h-full bg-red-500"></div></div>
                                 </div>
                                 <div className="flex items-center space-x-2 mt-2">
                                     <span className="text-xs w-8 text-gray-400">Avg</span>
                                     <div className="flex-1 h-2 bg-gray-700 rounded"><div className="w-[50%] h-full bg-amber-500"></div></div>
                                 </div>
                                 <div className="flex items-center space-x-2 mt-2">
                                     <span className="text-xs w-8 text-gray-400">Good</span>
                                     <div className="flex-1 h-2 bg-gray-700 rounded"><div className="w-[30%] h-full bg-green-500"></div></div>
                                 </div>
                             </div>
                             <div className="bg-brand-dark p-4 rounded border border-brand-light flex items-center justify-center">
                                 <div className="text-center">
                                     <p className="text-3xl font-bold text-white">4.2</p>
                                     <p className="text-xs text-gray-400">Avg Star Rating</p>
                                     <div className="flex text-amber-400 text-sm mt-1">★★★★☆</div>
                                 </div>
                             </div>
                        </div>
                    )
                };

          case 'category-recommendation':
              return {
                  kpis: [
                      { label: 'Category Growth', value: '+12.5%', change: 'YoY', changeColor: 'text-green-400' },
                      { label: 'Top Emerging Flavor', value: 'Yuzu & Mint', change: 'High Demand', changeColor: 'text-green-400' },
                      { label: 'Gap in Portfolio', value: '250ml Can', change: 'High Opportunity', changeColor: 'text-amber-400' },
                      { label: 'Est. Revenue Opp', value: '₹1.2Cr', change: 'Annual', changeColor: 'text-green-400' },
                  ],
                  columns: [
                      { id: 'variant', label: 'Variant / Flavor' },
                      { id: 'pack_size', label: 'Pack Size' },
                      { id: 'demand_index', label: 'Demand Index' },
                      { id: 'competition', label: 'Competition' },
                      { id: 'opportunity_score', label: 'Opp Score' },
                      { id: 'action', label: 'Action' },
                  ],
                  data: [
                      { variant: 'Yuzu & Mint', pack_size: '250ml Can', demand_index: '95/100', competition: 'Low', opportunity_score: 'High', impact: 'positive', action: 'Launch' },
                      { variant: 'Watermelon Electrolyte', pack_size: '500ml Bottle', demand_index: '88/100', competition: 'Medium', opportunity_score: 'High', impact: 'positive', action: 'Launch' },
                      { variant: 'Spicy Guava', pack_size: '200ml Tetra', demand_index: '72/100', competition: 'High', opportunity_score: 'Medium', impact: 'neutral', action: 'Monitor' },
                  ],
                  chartSection: (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          <div className="bg-brand-dark p-4 rounded border border-brand-light">
                              <h4 className="text-sm font-bold text-gray-300 mb-4">Flavor Demand vs Competition</h4>
                              <ScatterPlot 
                                  data={[
                                      { x: 20, y: 90, label: 'Yuzu', type: 'safe' },
                                      { x: 50, y: 80, label: 'Watermelon', type: 'safe' },
                                      { x: 80, y: 60, label: 'Guava', type: 'warning' },
                                      { x: 90, y: 40, label: 'Cola', type: 'warning' },
                                  ]} 
                                  xLabel="Competition Intensity" 
                                  yLabel="Consumer Demand" 
                              />
                          </div>
                          <div className="bg-brand-dark p-4 rounded border border-brand-light">
                              <h4 className="text-sm font-bold text-gray-300 mb-4">Pack Size Preference Trend</h4>
                              <SimpleBarChart 
                                  data={[
                                      { label: '250ml Can', value: 85, color: '#34d399' },
                                      { label: '500ml Bottle', value: 65, color: '#60a5fa' },
                                      { label: '1L Bottle', value: 30, color: '#9ca3af' },
                                      { label: 'Multipack', value: 45, color: '#f59e0b' },
                                  ]} 
                                  height={200} 
                                  showValue 
                              />
                          </div>
                      </div>
                  )
              };

          default: // Market Share & Ad Optimisation & Others
              return {
                  kpis: [
                      { label: 'Total Sales', value: '₹54,700', change: '↑ 12%', changeColor: 'text-green-400' },
                      { label: 'Avg Margin', value: '20.5%', change: '↓ 1.2%', changeColor: 'text-amber-400' },
                      { label: 'Ad ROAS', value: '3.2x', change: '↑ 0.4', changeColor: 'text-green-400' },
                      { label: 'ACOS', value: '28%', change: '↓ 2%', changeColor: 'text-green-400' },
                  ],
                  columns: [
                      { id: 'sku', label: 'SKU ID' },
                      { id: 'product', label: 'Product Name' },
                      { id: 'retailer', label: 'Retailer' },
                      { id: 'city', label: 'City' },
                      { id: 'sales', label: 'Sales Val' },
                      { id: 'margin', label: 'Margin %' },
                  ],
                  data: [
                      { sku: 'SKU-101', product: 'SuperBoost', retailer: 'Amazon', city: 'Mumbai', sales: '₹12,500', margin: '22%', impact: 'positive' },
                      { sku: 'SKU-205', product: 'Pro-Hydrate', retailer: 'Zepto', city: 'Delhi', sales: '₹2,100', margin: '15%', impact: 'negative' },
                  ],
                  chartSection: (
                       <div className="bg-brand-dark p-5 rounded-lg border border-brand-light shadow-lg">
                           <h3 className="text-sm font-bold text-gray-200 mb-4">Sales vs Spend Analysis</h3>
                           <div className="h-48 flex items-end justify-between space-x-4">
                               {[1,2,3,4,5,6,7].map(i => (
                                   <div key={i} className="flex-1 flex flex-col justify-end h-full space-y-1">
                                       <div className="bg-blue-500 w-full rounded-t" style={{height: `${Math.random()*60}%`}}></div>
                                       <div className="bg-green-500 w-full rounded-b opacity-60" style={{height: `${Math.random()*40}%`}}></div>
                                   </div>
                               ))}
                           </div>
                           <div className="flex justify-center mt-2 space-x-4 text-xs">
                               <span className="flex items-center"><span className="w-2 h-2 bg-blue-500 mr-1"></span> Sales</span>
                               <span className="flex items-center"><span className="w-2 h-2 bg-green-500 mr-1"></span> Spend</span>
                           </div>
                       </div>
                  )
              };
      }
  }

  if (!config) return <div className="p-10 text-white">Loading configuration...</div>;

  return (
    <div className="bg-brand-medium h-full flex flex-col animate-fadeIn">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-6 border-b border-brand-light bg-brand-dark">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-brand-accent/20 rounded-lg">
            <TableCellsIcon className="w-6 h-6 text-brand-accent" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Deep Dive: {activeModule.name}</h2>
            <p className="text-sm text-gray-400">Contextual analysis for {activeModule.name} module.</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => setIsReportBuilderOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-brand-accent hover:bg-blue-600 text-white rounded transition-colors text-sm font-bold shadow-md"
          >
            <DocumentPlusIcon className="w-4 h-4" />
            <span>Create Report</span>
          </button>
          <button 
            onClick={() => setIsExportOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-brand-medium border border-brand-light hover:bg-brand-light text-white rounded transition-colors text-sm font-medium"
          >
            <ArrowDownTrayIcon className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
          <button 
            onClick={onClose}
            className="flex items-center space-x-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded transition-colors text-sm font-medium"
          >
            <CloseIcon className="w-5 h-5" />
            <span>Close</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Filters Panel */}
        <div className="w-64 bg-brand-dark border-r border-brand-light p-4 flex flex-col space-y-6 overflow-y-auto hidden md:flex">
            <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Dimensions</h4>
                <div className="space-y-2">
                    <label className="flex items-center space-x-2 text-sm text-gray-300 cursor-pointer">
                        <input type="checkbox" className="rounded border-gray-600 bg-brand-medium" defaultChecked />
                        <span>Retailer</span>
                    </label>
                    <label className="flex items-center space-x-2 text-sm text-gray-300 cursor-pointer">
                        <input type="checkbox" className="rounded border-gray-600 bg-brand-medium" defaultChecked />
                        <span>City / Region</span>
                    </label>
                    <label className="flex items-center space-x-2 text-sm text-gray-300 cursor-pointer">
                        <input type="checkbox" className="rounded border-gray-600 bg-brand-medium" defaultChecked />
                        <span>SKU Category</span>
                    </label>
                </div>
            </div>

            <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Time Period</h4>
                <select className="w-full bg-brand-medium border border-brand-light rounded p-2 text-sm text-white">
                    <option>Last 4 Weeks</option>
                    <option>Last 13 Weeks</option>
                    <option>Year to Date</option>
                    <option>Last 52 Weeks</option>
                </select>
            </div>
            
            <div className="p-4 bg-brand-accent/10 rounded border border-brand-accent/20">
                <p className="text-xs font-bold text-brand-accent mb-2">Deep Dive Filter</p>
                <input type="text" placeholder="Search..." className="w-full bg-brand-medium border border-brand-light rounded p-2 text-xs text-white focus:border-brand-accent focus:outline-none" />
            </div>

            <div className="mt-auto p-4 bg-brand-medium/30 rounded border border-brand-light/30">
                <p className="text-xs text-gray-400 mb-1">Data Freshness</p>
                <p className="text-sm font-bold text-green-400">Live (15 min lag)</p>
            </div>
        </div>

        {/* Content Container */}
        <div className="flex-1 flex flex-col overflow-y-auto bg-brand-medium">
            
            {/* ANALYTICS STRIP (Context Aware) */}
            <div className="p-6 pb-2 grid grid-cols-1 md:grid-cols-4 gap-4">
                {config.kpis.map((kpi, idx) => (
                    <div key={idx} className="bg-brand-dark p-4 rounded-lg border border-brand-light shadow-sm">
                        <p className="text-xs text-gray-400 uppercase font-bold">{kpi.label}</p>
                        <p className="text-2xl font-bold text-white mt-1">{kpi.value}</p>
                        <span className={`text-xs ${kpi.changeColor}`}>{kpi.change}</span>
                    </div>
                ))}
            </div>

            {/* CHART SECTION (Context Aware) */}
            <div className="px-6 mt-4">
                {config.chartSection}
            </div>

            {/* DATA GRID (Context Aware) */}
            <div className="flex-1 p-6 pt-6">
                <div className="bg-brand-dark rounded-lg shadow-lg border border-brand-light overflow-hidden">
                    <div className="p-4 border-b border-brand-light flex justify-between items-center bg-brand-medium/50">
                        <h3 className="text-sm font-bold text-gray-200">Detailed Records</h3>
                        <span className="text-xs text-gray-500">Showing {config.data.length} records</span>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse min-w-max">
                            <thead className="bg-brand-medium">
                                <tr>
                                    {config.columns.filter(c => selectedColumns.includes(c.id)).map(col => (
                                        <th key={col.id} className="p-4 text-xs font-bold text-gray-300 uppercase tracking-wider border-b border-brand-light">
                                            <div className="flex items-center space-x-1 cursor-pointer hover:text-white">
                                                <span>{col.label}</span>
                                                <FilterIcon className="w-3 h-3" />
                                            </div>
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-brand-light/30">
                                {config.data.map((row, idx) => (
                                    <tr key={idx} className="hover:bg-brand-light/10 transition-colors group">
                                        {config.columns.filter(c => selectedColumns.includes(c.id)).map(col => {
                                            const val = row[col.id];
                                            let cellClass = "p-4 text-sm text-gray-300";
                                            // Simple highlight logic based on row impact
                                            if (row.impact === 'negative' && idx === 0) { // Highlight first col if negative
                                                 cellClass += " font-medium text-red-300";
                                            }
                                            
                                            if (col.id === 'action') {
                                                return (
                                                    <td key={col.id} className={cellClass}>
                                                        <button 
                                                            onClick={() => {
                                                                if (val === 'Rewrite') {
                                                                    setRewriteData({
                                                                        sku: row.sku as string,
                                                                        title: 'SuperBoost Energy Drink - 250ml', // Mock data
                                                                        description: 'Energy drink for sports and gym. Contains caffeine and taurine.'
                                                                    });
                                                                    setIsRewriteOpen(true);
                                                                } else if (val === 'Launch') {
                                                                    alert('Initiating NPD workflow...');
                                                                }
                                                            }}
                                                            className={`px-3 py-1 rounded text-xs font-bold hover:opacity-80 transition-opacity ${
                                                                val === 'Rewrite' ? 'bg-brand-accent text-white' : 
                                                                val === 'Launch' ? 'bg-green-500 text-white' : 
                                                                'bg-gray-700 text-gray-300'
                                                            }`}
                                                        >
                                                            {val}
                                                        </button>
                                                    </td>
                                                );
                                            }

                                            return (
                                                <td key={col.id} className={cellClass}>
                                                    {val}
                                                </td>
                                            );
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      </div>

      {/* Export Data Modal */}
      {isExportOpen && (
          <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
              <div className="bg-brand-dark w-full max-w-md rounded-xl border border-brand-light shadow-2xl p-6">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-bold text-white">Export Raw Data</h3>
                      <button onClick={() => setIsExportOpen(false)}><CloseIcon className="w-5 h-5 text-gray-400 hover:text-white"/></button>
                  </div>
                  <p className="text-sm text-gray-400 mb-4">Select columns to include in your CSV export.</p>
                  
                  <div className="grid grid-cols-2 gap-3 mb-6 max-h-60 overflow-y-auto p-1">
                      {config.columns.map(col => (
                          <label key={col.id} className="flex items-center space-x-2 text-sm text-gray-200 cursor-pointer p-2 rounded hover:bg-brand-medium">
                              <input 
                                type="checkbox" 
                                checked={selectedColumns.includes(col.id)}
                                onChange={() => toggleColumn(col.id)}
                                className="rounded border-gray-600 bg-brand-light text-brand-accent focus:ring-brand-accent"
                              />
                              <span>{col.label}</span>
                          </label>
                      ))}
                  </div>

                  <div className="flex space-x-3">
                      <button 
                        onClick={() => setIsExportOpen(false)}
                        className="flex-1 py-2 bg-brand-light text-white rounded hover:bg-gray-600 transition-colors text-sm font-medium"
                      >
                          Cancel
                      </button>
                      <button className="flex-1 py-2 bg-brand-accent text-white rounded hover:bg-blue-600 transition-colors text-sm font-bold flex items-center justify-center space-x-2">
                          <ArrowDownTrayIcon className="w-4 h-4" />
                          <span>Download CSV</span>
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Report Builder Modal */}
      {isReportBuilderOpen && (
          <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
              <div className="bg-brand-dark w-full max-w-lg rounded-xl border border-brand-light shadow-2xl p-6">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-white">Create Custom Report</h3>
                      <button onClick={() => setIsReportBuilderOpen(false)}><CloseIcon className="w-6 h-6 text-gray-400 hover:text-white"/></button>
                  </div>
                  
                  <div className="space-y-6">
                      <div>
                          <label className="block text-sm font-bold text-gray-300 mb-2">Report Name</label>
                          <input type="text" defaultValue={`Deep Dive - ${activeModule.name} - ${new Date().toLocaleDateString()}`} className="w-full bg-brand-medium border border-brand-light rounded p-2 text-white focus:border-brand-accent focus:outline-none" />
                      </div>

                      <div>
                          <label className="block text-sm font-bold text-gray-300 mb-2">Report Type</label>
                          <div className="grid grid-cols-2 gap-4">
                              <button className="p-3 rounded border border-brand-accent bg-brand-accent/10 text-left hover:bg-brand-accent/20 transition-colors">
                                  <p className="text-sm font-bold text-white">Executive Summary</p>
                                  <p className="text-xs text-gray-400 mt-1">High-level insights & KPIs suitable for leadership.</p>
                              </button>
                              <button className="p-3 rounded border border-brand-light bg-brand-medium text-left hover:border-gray-500 transition-colors">
                                  <p className="text-sm font-bold text-gray-300">Detailed Audit</p>
                                  <p className="text-xs text-gray-500 mt-1">Full granular data breakdown with anomaly logs.</p>
                              </button>
                          </div>
                      </div>

                      <div>
                          <label className="block text-sm font-bold text-gray-300 mb-2">Format</label>
                          <select className="w-full bg-brand-medium border border-brand-light rounded p-2 text-white focus:outline-none focus:border-brand-accent">
                              <option>PDF Document</option>
                              <option>PowerPoint Presentation (PPTX)</option>
                              <option>Excel Workbook (XLSX)</option>
                          </select>
                      </div>

                       <div className="p-4 bg-brand-medium rounded border border-brand-light">
                           <div className="flex items-center space-x-2">
                               <input type="checkbox" defaultChecked className="rounded border-gray-600 bg-brand-light text-brand-accent focus:ring-brand-accent" />
                               <span className="text-sm text-gray-300">Include AI-generated summary & recommendations</span>
                           </div>
                       </div>
                  </div>

                  <div className="flex space-x-3 mt-8">
                      <button 
                        onClick={() => setIsReportBuilderOpen(false)}
                        className="flex-1 py-3 bg-brand-light text-white rounded hover:bg-gray-600 transition-colors text-sm font-bold"
                      >
                          Cancel
                      </button>
                      <button className="flex-1 py-3 bg-brand-accent text-white rounded hover:bg-blue-600 transition-colors text-sm font-bold flex items-center justify-center space-x-2">
                          <DocumentPlusIcon className="w-5 h-5" />
                          <span>Generate Report</span>
                      </button>
                  </div>
              </div>
          </div>
      )}
      {/* Content Rewrite Modal */}
      {isRewriteOpen && rewriteData && (
          <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
              <div className="bg-brand-dark w-full max-w-2xl rounded-xl border border-brand-light shadow-2xl p-6">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-white">AI Content Optimization</h3>
                      <button onClick={() => setIsRewriteOpen(false)}><CloseIcon className="w-6 h-6 text-gray-400 hover:text-white"/></button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6">
                      {/* Original */}
                      <div className="space-y-4">
                          <h4 className="text-sm font-bold text-gray-400 uppercase">Current Content</h4>
                          <div className="p-4 bg-brand-medium/50 rounded border border-brand-light">
                              <p className="text-xs text-gray-500 mb-1">Title</p>
                              <p className="text-sm text-white mb-4">{rewriteData.title}</p>
                              <p className="text-xs text-gray-500 mb-1">Description</p>
                              <p className="text-xs text-gray-300">{rewriteData.description}</p>
                          </div>
                      </div>

                      {/* AI Suggestion */}
                      <div className="space-y-4">
                          <h4 className="text-sm font-bold text-brand-accent uppercase flex items-center">
                              <span className="mr-2">✨</span> AI Suggestion
                          </h4>
                          <div className="p-4 bg-brand-accent/10 rounded border border-brand-accent/30 relative">
                              <div className="absolute top-2 right-2 px-2 py-0.5 bg-green-500 text-white text-[10px] font-bold rounded">Score: 92</div>
                              <p className="text-xs text-brand-accent mb-1">Optimized Title</p>
                              <p className="text-sm text-white mb-4 font-medium">SuperBoost Energy Drink 250ml | Zero Sugar | Pre-Workout Focus & Stamina | Caffeine + Taurine</p>
                              <p className="text-xs text-brand-accent mb-1">Enhanced Description</p>
                              <p className="text-xs text-gray-300">
                                  Unleash your potential with SuperBoost Energy. Formulated for athletes and professionals, this zero-sugar blend delivers sustained energy without the crash. Packed with B-Vitamins, Taurine, and Caffeine for peak mental focus.
                              </p>
                          </div>
                      </div>
                  </div>

                  <div className="flex justify-end space-x-3 mt-8">
                      <button 
                        onClick={() => setIsRewriteOpen(false)}
                        className="px-4 py-2 bg-brand-light text-white rounded hover:bg-gray-600 transition-colors text-sm font-bold"
                      >
                          Discard
                      </button>
                      <button 
                        onClick={() => {
                            alert('Content updated successfully!');
                            setIsRewriteOpen(false);
                        }}
                        className="px-4 py-2 bg-brand-accent text-white rounded hover:bg-blue-600 transition-colors text-sm font-bold"
                      >
                          Apply Changes
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default AnalyticalDashboard;
