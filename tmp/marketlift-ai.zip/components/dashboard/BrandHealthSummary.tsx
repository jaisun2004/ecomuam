
import React from 'react';
import { brandHealthMetrics } from '../../data/mockData';
import { MetricTile } from '../shared/Visuals';

const BrandHealthSummary: React.FC = () => {
  return (
    <div className="bg-brand-dark border-b border-brand-light p-4">
        <div className="container mx-auto">
             <h2 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wide">Brand Health Summary (Last 4 Weeks)</h2>
             <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {brandHealthMetrics.map((metric, idx) => (
                    <MetricTile key={idx} {...metric} />
                ))}
             </div>
        </div>
    </div>
  );
};

export default BrandHealthSummary;
