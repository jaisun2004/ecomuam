
import React from 'react';

// --- Metric Card ---
export const MetricTile: React.FC<{
  label: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'flat';
  status: 'healthy' | 'monitor' | 'critical';
}> = ({ label, value, change, trend, status }) => {
  const statusColors = {
    healthy: 'text-green-600 bg-green-50 px-2 py-0.5 rounded',
    monitor: 'text-amber-600 bg-amber-50 px-2 py-0.5 rounded',
    critical: 'text-red-600 bg-red-50 px-2 py-0.5 rounded',
  };
  
  const trendIcons = {
    up: '↑',
    down: '↓',
    flat: '→',
  };

  return (
    <div className="bg-white rounded-lg p-4 border border-gray-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
      <span className="text-black text-xs font-bold uppercase tracking-wider">{label}</span>
      <div className="flex items-end justify-between mt-2">
        <span className="text-2xl font-bold text-gray-900">{value}</span>
        <div className={`flex items-center text-xs font-bold ${statusColors[status]}`}>
          <span className="mr-1">{trendIcons[trend]}</span>
          {change}
        </div>
      </div>
    </div>
  );
};

// --- Simple Bar Chart ---
export const SimpleBarChart: React.FC<{
  data: { label: string; value: number; color?: string }[];
  height?: number;
  showValue?: boolean;
}> = ({ data, height = 150, showValue = false }) => {
  const maxValue = Math.max(...data.map(d => d.value));

  return (
    <div className="flex items-end space-x-4 w-full" style={{ height: `${height}px` }}>
      {data.map((d, idx) => (
        <div key={idx} className="flex-1 flex flex-col items-center group relative">
           {showValue && (
               <span className="text-xs text-black font-bold mb-1 opacity-0 group-hover:opacity-100 transition-opacity absolute -top-5">
                   {d.value}
               </span>
           )}
          <div 
            className="w-full rounded-t-sm transition-all duration-500 hover:brightness-110"
            style={{ 
                height: `${(d.value / maxValue) * 100}%`,
                backgroundColor: d.color || '#3b82f6' 
            }}
          />
          <span className="text-xs text-black mt-2 truncate w-full text-center font-medium">{d.label}</span>
        </div>
      ))}
    </div>
  );
};

// --- Waterfall Chart ---
export const WaterfallChart: React.FC<{
  data: { label: string; value: number; type: 'base' | 'positive' | 'negative' | 'total' }[];
}> = ({ data }) => {
    let currentBase = 0;
    
    return (
        <div className="flex items-end space-x-2 h-48 w-full mt-4">
            {data.map((d, i) => {
                const isTotal = d.type === 'base' || d.type === 'total';
                const height = Math.abs(d.value);
                const start = isTotal ? 0 : (d.value > 0 ? currentBase : currentBase - height);
                
                if (!isTotal) currentBase += d.value;
                else currentBase = d.value;

                // Normalize for visualization (mocking scale)
                const scale = 1.5; 
                
                let bgClass = 'bg-gray-400';
                if (d.type === 'positive') bgClass = 'bg-green-500';
                if (d.type === 'negative') bgClass = 'bg-red-500';
                if (d.type === 'total') bgClass = 'bg-brand-accent';

                return (
                    <div key={i} className="flex-1 flex flex-col justify-end relative group">
                        <div 
                            className={`w-full ${bgClass} rounded-sm relative shadow-sm`}
                            style={{
                                height: `${Math.max(height * scale, 4)}px`,
                                marginBottom: `${start * scale}px`
                            }}
                        >
                             <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs text-black font-bold opacity-0 group-hover:opacity-100">
                                {d.value > 0 && !isTotal ? '+' : ''}{d.value}
                            </span>
                        </div>
                        <span className="text-[10px] text-black text-center mt-1 truncate font-medium">{d.label}</span>
                    </div>
                )
            })}
        </div>
    )
}

// --- Status Badge ---
export const StatusBadge: React.FC<{ status: 'ok' | 'warning' | 'critical' }> = ({ status }) => {
    const colors = {
        ok: 'bg-green-100 text-green-700 border-green-200',
        warning: 'bg-amber-100 text-amber-700 border-amber-200',
        critical: 'bg-red-100 text-red-700 border-red-200',
    };
    return (
        <span className={`px-2 py-0.5 rounded text-xs font-bold border ${colors[status]} uppercase`}>
            {status}
        </span>
    );
};

// --- Heatmap Grid (for ROAS) ---
export const HeatmapGrid: React.FC<{
    data: { sku: string; retailers: { name: string; roas: number }[] }[];
}> = ({ data }) => {
    const getRoasColor = (roas: number) => {
        if (roas >= 4) return 'bg-green-500 text-white font-bold shadow-sm';
        if (roas >= 2.5) return 'bg-green-100 text-green-800 font-medium';
        if (roas > 0) return 'bg-amber-100 text-amber-800 font-medium';
        return 'bg-red-100 text-red-800 font-medium'; // ROAS 0 or very low
    };

    return (
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr>
                        <th className="p-2 text-xs text-black font-bold border-b border-gray-200 uppercase tracking-wider">SKU</th>
                        {data[0].retailers.map((r, i) => (
                            <th key={i} className="p-2 text-xs text-black font-bold border-b border-gray-200 text-center uppercase tracking-wider">{r.name}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, i) => (
                        <tr key={i} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                            <td className="p-2 text-xs font-mono text-black font-medium">{row.sku}</td>
                            {row.retailers.map((r, j) => (
                                <td key={j} className="p-2 text-center">
                                    <div className={`py-1 px-2 rounded text-xs inline-block min-w-[3rem] ${getRoasColor(r.roas)}`}>
                                        {r.roas.toFixed(1)}x
                                    </div>
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

// --- Scatter Plot (Simplified) ---
export const ScatterPlot: React.FC<{
    data: { x: number; y: number; label: string; type: 'safe' | 'warning' }[];
    xLabel: string;
    yLabel: string;
    maxX?: number;
    maxY?: number;
}> = ({ data, xLabel, yLabel, maxX = 100, maxY = 100 }) => {
    return (
        <div className="h-64 relative bg-gray-50 rounded border border-gray-200 m-2">
             <div className="absolute inset-8 border-l border-b border-gray-300">
                {data.map((d, i) => (
                    <div 
                        key={i}
                        className={`absolute w-3 h-3 rounded-full transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group shadow-sm border border-white ${d.type === 'safe' ? 'bg-green-500' : 'bg-red-500'}`}
                        style={{ left: `${(d.x / maxX) * 100}%`, bottom: `${(d.y / maxY) * 100}%` }}
                    >
                         <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-gray-900 text-xs text-white p-2 rounded shadow-lg opacity-0 group-hover:opacity-100 whitespace-nowrap z-10 font-medium">
                             {d.label} (x: {d.x}, y: {d.y})
                         </div>
                    </div>
                ))}
             </div>
             <span className="absolute bottom-1 right-4 text-[10px] text-black uppercase font-bold tracking-wider">{xLabel}</span>
             <span className="absolute top-4 left-1 text-[10px] text-black uppercase font-bold tracking-wider -rotate-90 origin-left">{yLabel}</span>
        </div>
    )
}

// --- Share of Shelf Visuals ---
export const ShareOfShelfVisuals: React.FC = () => {
    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-4 rounded border border-gray-200 shadow-sm">
                    <h4 className="text-sm font-bold text-gray-900 mb-4">Organic vs Sponsored Rank Distribution</h4>
                    <div className="h-48 flex items-end space-x-4">
                         {/* Organic */}
                         <div className="flex-1 flex flex-col items-center space-y-2">
                             <div className="w-full flex space-x-1 items-end h-full justify-center">
                                 <div className="w-4 bg-green-500 rounded-t" style={{height: '80%'}}></div>
                                 <div className="w-4 bg-green-300 rounded-t" style={{height: '40%'}}></div>
                                 <div className="w-4 bg-green-100 rounded-t" style={{height: '20%'}}></div>
                             </div>
                             <span className="text-xs text-black font-medium">Organic</span>
                         </div>
                         {/* Sponsored */}
                         <div className="flex-1 flex flex-col items-center space-y-2">
                             <div className="w-full flex space-x-1 items-end h-full justify-center">
                                 <div className="w-4 bg-blue-500 rounded-t" style={{height: '90%'}}></div>
                                 <div className="w-4 bg-blue-300 rounded-t" style={{height: '30%'}}></div>
                                 <div className="w-4 bg-blue-100 rounded-t" style={{height: '10%'}}></div>
                             </div>
                             <span className="text-xs text-black font-medium">Sponsored</span>
                         </div>
                    </div>
                    <div className="flex justify-center space-x-4 mt-2">
                        <span className="text-[10px] text-black flex items-center font-medium"><span className="w-2 h-2 bg-gray-400 mr-1"></span>Top 3</span>
                        <span className="text-[10px] text-black flex items-center font-medium"><span className="w-2 h-2 bg-gray-300 mr-1"></span>Page 1</span>
                        <span className="text-[10px] text-black flex items-center font-medium"><span className="w-2 h-2 bg-gray-200 mr-1"></span>Page 2+</span>
                    </div>
                </div>

                <div className="bg-white p-4 rounded border border-gray-200 shadow-sm">
                    <h4 className="text-sm font-bold text-gray-900 mb-4">Share of Voice (SOV) Split</h4>
                    <div className="flex items-center justify-center h-48">
                        <div className="relative w-32 h-32 rounded-full border-8 border-gray-100 flex items-center justify-center">
                            <div className="absolute inset-0 rounded-full border-8 border-green-500" style={{clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)', transform: 'rotate(45deg)'}}></div>
                            <div className="absolute inset-0 rounded-full border-8 border-blue-500" style={{clipPath: 'polygon(0 0, 100% 0, 100% 30%, 0 30%)', transform: 'rotate(-90deg)'}}></div>
                            <div className="text-center">
                                <p className="text-2xl font-bold text-gray-900">45%</p>
                                <p className="text-[10px] text-black font-bold uppercase">Total SOV</p>
                            </div>
                        </div>
                        <div className="ml-8 space-y-2">
                            <div className="flex items-center space-x-2">
                                <span className="w-3 h-3 bg-green-500 rounded-full"></span>
                                <span className="text-xs text-black font-medium">Organic (30%)</span>
                            </div>
                            <div className="flex items-center space-x-2">
                                <span className="w-3 h-3 bg-blue-500 rounded-full"></span>
                                <span className="text-xs text-black font-medium">Sponsored (15%)</span>
                            </div>
                            <div className="flex items-center space-x-2">
                                <span className="w-3 h-3 bg-gray-200 rounded-full border border-gray-300"></span>
                                <span className="text-xs text-black font-medium">Competitors (55%)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- Diagnostic Tree (Module 5C) ---
export const DiagnosticTree: React.FC<{ initialType?: 'pricing' | 'availability' | 'organic' | 'sponsored' }> = ({ initialType = 'pricing' }) => {
    const [step, setStep] = React.useState(0);
    const [type, setType] = React.useState(initialType);
    const [selectedPlatform, setSelectedPlatform] = React.useState<string | null>(null);
    const [selectedCity, setSelectedCity] = React.useState<string | null>(null);
    const [selectedSku, setSelectedSku] = React.useState<string | null>(null);

    const ladderData = {
        platforms: ['Amazon', 'Blinkit'],
        cities: {
            'Amazon': ['National'],
            'Blinkit': ['Mumbai', 'Bengaluru', 'Delhi NCR']
        },
        skus: {
            'Mumbai': ['SKU-205 (Hydrate)', 'SKU-101 (Energy)'],
            'National': ['SKU-101 (Energy)', 'SKU-300 (Tea)']
        },
        variants: {
            'SKU-205 (Hydrate)': ['500g Pack', '1kg Value Pack'],
            'SKU-101 (Energy)': ['250ml Can', '500ml Bottle']
        }
    };

    const getIssueLabel = () => {
        switch(type) {
            case 'availability': return 'Availability Gap';
            case 'organic': return 'Organic Rank Drop';
            case 'sponsored': return 'Sponsored SOV Loss';
            default: return 'Price Gap > 15%';
        }
    };

    const reset = () => {
        setStep(0);
        setSelectedPlatform(null);
        setSelectedCity(null);
        setSelectedSku(null);
    };

    return (
        <div className="flex flex-col items-center justify-center space-y-6 p-6 bg-gray-50 rounded-xl border border-gray-200 shadow-sm">
             {/* Root / Header */}
             <div className="text-center mb-4">
                 <h4 className="text-lg font-bold text-gray-900 uppercase tracking-tight">{type.replace('-', ' ')} Drill-down</h4>
                 <p className="text-xs text-black font-medium">Identify the specific variant causing share loss</p>
                 
                 <div className="flex space-x-2 mt-4 justify-center">
                     {['pricing', 'availability', 'organic', 'sponsored'].map(t => (
                         <button 
                            key={t}
                            onClick={() => { setType(t as any); reset(); }}
                            className={`px-3 py-1 text-[10px] font-bold rounded border transition-colors ${type === t ? 'bg-brand-accent border-brand-accent text-white shadow-sm' : 'bg-white border-gray-300 text-black hover:text-brand-accent hover:border-brand-accent'}`}
                         >
                             {t.toUpperCase()}
                         </button>
                     ))}
                 </div>
             </div>

             <div className="flex flex-col items-center space-y-4 w-full max-w-2xl">
                {/* Step 0: Platform */}
                <div className="flex flex-col items-center w-full">
                    <div className="flex space-x-4">
                        {ladderData.platforms.map(p => (
                            <button 
                                key={p}
                                onClick={() => { setSelectedPlatform(p); setStep(1); setSelectedCity(null); setSelectedSku(null); }}
                                className={`px-6 py-3 rounded-lg border transition-all ${selectedPlatform === p ? 'bg-brand-accent border-brand-accent text-white shadow-md scale-105' : 'bg-white border-gray-200 text-black hover:border-brand-accent hover:text-brand-accent'}`}
                            >
                                <p className="text-[10px] uppercase font-bold opacity-80">Platform</p>
                                <p className="font-bold">{p}</p>
                            </button>
                        ))}
                    </div>
                </div>

                {step >= 1 && selectedPlatform && (
                    <>
                        <div className="h-6 w-0.5 bg-gray-300"></div>
                        <div className="flex flex-col items-center w-full">
                            <div className="flex flex-wrap justify-center gap-3">
                                {(ladderData.cities as any)[selectedPlatform].map((c: string) => (
                                    <button 
                                        key={c}
                                        onClick={() => { setSelectedCity(c); setStep(2); setSelectedSku(null); }}
                                        className={`px-4 py-2 rounded-lg border transition-all ${selectedCity === c ? 'bg-brand-accent border-brand-accent text-white shadow-md' : 'bg-white border-gray-200 text-black hover:border-brand-accent hover:text-brand-accent'}`}
                                    >
                                        <p className="text-[10px] uppercase font-bold opacity-80">City</p>
                                        <p className="font-bold text-sm">{c}</p>
                                    </button>
                                ))}
                            </div>
                        </div>
                    </>
                )}

                {step >= 2 && selectedCity && (ladderData.skus as any)[selectedCity] && (
                    <>
                        <div className="h-6 w-0.5 bg-gray-300"></div>
                        <div className="flex flex-col items-center w-full">
                            <div className="flex flex-wrap justify-center gap-3">
                                {(ladderData.skus as any)[selectedCity].map((s: string) => (
                                    <button 
                                        key={s}
                                        onClick={() => { setSelectedSku(s); setStep(3); }}
                                        className={`px-4 py-2 rounded-lg border transition-all ${selectedSku === s ? 'bg-brand-accent border-brand-accent text-white shadow-md' : 'bg-white border-gray-200 text-black hover:border-brand-accent hover:text-brand-accent'}`}
                                    >
                                        <p className="text-[10px] uppercase font-bold opacity-80">SKU</p>
                                        <p className="font-bold text-sm">{s}</p>
                                    </button>
                                ))}
                            </div>
                        </div>
                    </>
                )}

                {step >= 3 && selectedSku && (ladderData.variants as any)[selectedSku] && (
                    <>
                        <div className="h-6 w-0.5 bg-gray-300"></div>
                        <div className="flex flex-col items-center w-full">
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full px-10">
                                {(ladderData.variants as any)[selectedSku].map((v: string) => (
                                    <div 
                                        key={v}
                                        className="p-4 bg-red-50 border border-red-200 rounded-xl text-center animate-pulse shadow-sm"
                                    >
                                        <p className="text-[10px] text-red-600 uppercase font-bold">Critical Issue: {getIssueLabel()}</p>
                                        <p className="font-bold text-gray-900 mt-1">{v}</p>
                                        <div className="mt-3 flex justify-center space-x-2">
                                            <button className="px-3 py-1 bg-red-600 text-white text-[10px] font-bold rounded hover:bg-red-700 transition-colors shadow-sm">
                                                Take Action
                                            </button>
                                            <button className="px-3 py-1 bg-brand-accent text-white text-[10px] font-bold rounded hover:bg-blue-700 transition-colors shadow-sm">
                                                View Details
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </>
                )}

                {step > 0 && (
                    <button 
                        onClick={reset}
                        className="mt-6 text-xs text-black hover:text-brand-accent underline underline-offset-4 font-medium"
                    >
                        Reset Drill-down
                    </button>
                )}
             </div>
        </div>
    )
}

// --- Assortment Visual (Module 6) ---
export const AssortmentVisual: React.FC = () => {
    const assortmentData = [
        { grammage: '100g', price: 45, stock: 'In Stock', demand: 'High', count: 12 },
        { grammage: '250g', price: 95, stock: 'OOS', demand: 'Medium', count: 25 },
        { grammage: '500g', price: 180, stock: 'In Stock', demand: 'High', count: 42 },
        { grammage: '1kg', price: 340, stock: 'Low Stock', demand: 'Low', count: 18 },
        { grammage: '2kg', price: 620, stock: 'In Stock', demand: 'Low', count: 5 },
    ];

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Grammage vs Price Scatter */}
                <div className="bg-white p-4 rounded border border-gray-200 shadow-sm">
                    <h4 className="text-sm font-bold text-gray-900 mb-4">Grammage vs Price (Assortment Map)</h4>
                    <div className="h-48 relative border-l border-b border-gray-300 ml-8 mb-8">
                        {assortmentData.map((d, i) => (
                            <div 
                                key={i}
                                className={`absolute w-4 h-4 rounded-full flex items-center justify-center group cursor-pointer shadow-sm border border-white ${d.stock === 'OOS' ? 'bg-red-500' : d.stock === 'Low Stock' ? 'bg-amber-500' : 'bg-brand-accent'}`}
                                style={{ 
                                    left: `${(i / (assortmentData.length - 1)) * 90 + 5}%`, 
                                    bottom: `${(d.price / 700) * 90 + 5}%` 
                                }}
                            >
                                <div className="absolute bottom-full mb-2 bg-gray-900 text-[10px] text-white p-2 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-10 shadow-lg font-medium">
                                    {d.grammage}: ₹{d.price} ({d.stock})
                                </div>
                            </div>
                        ))}
                        <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] text-black uppercase font-bold">Grammage (Size)</span>
                        <span className="absolute -left-10 top-1/2 -translate-y-1/2 -rotate-90 text-[10px] text-black uppercase font-bold">Price (₹)</span>
                    </div>
                </div>

                {/* Grammage Distribution */}
                <div className="bg-white p-4 rounded border border-gray-200 shadow-sm">
                    <h4 className="text-sm font-bold text-gray-900 mb-4">Most Common Grammage (Distribution)</h4>
                    <div className="h-48 flex items-end space-x-4">
                        {assortmentData.map((d, i) => (
                            <div key={i} className="flex-1 flex flex-col items-center group">
                                <div className="w-full bg-blue-100 group-hover:bg-blue-200 transition-colors rounded-t" style={{ height: `${(d.count / 50) * 100}%` }}></div>
                                <span className="text-[10px] text-black mt-2 font-medium">{d.grammage}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Stock Status by Variant */}
                <div className="bg-white p-4 rounded border border-gray-200 shadow-sm">
                    <h4 className="text-sm font-bold text-gray-900 mb-4">Stock Status by Variant</h4>
                    <div className="space-y-3">
                        {assortmentData.map((d, i) => (
                            <div key={i} className="flex items-center justify-between">
                                <span className="text-xs text-black font-medium">{d.grammage} Variant</span>
                                <div className="flex items-center space-x-2">
                                    <div className="w-32 h-2 bg-gray-100 rounded overflow-hidden">
                                        <div className={`h-full ${d.stock === 'OOS' ? 'bg-red-500' : d.stock === 'Low Stock' ? 'bg-amber-500' : 'bg-green-500'}`} style={{ width: d.stock === 'OOS' ? '10%' : d.stock === 'Low Stock' ? '40%' : '100%' }}></div>
                                    </div>
                                    <span className={`text-[10px] font-bold ${d.stock === 'OOS' ? 'text-red-600' : d.stock === 'Low Stock' ? 'text-amber-600' : 'text-green-600'}`}>{d.stock}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Category Demands */}
                <div className="bg-white p-4 rounded border border-gray-200 shadow-sm">
                    <h4 className="text-sm font-bold text-gray-900 mb-4">Category Demand Index</h4>
                    <div className="space-y-4">
                        {assortmentData.filter(d => d.demand === 'High' || d.demand === 'Medium').map((d, i) => (
                            <div key={i} className="flex items-center space-x-4">
                                <div className={`w-10 h-10 rounded flex items-center justify-center font-bold text-white shadow-sm ${d.demand === 'High' ? 'bg-red-500' : 'bg-amber-500'}`}>
                                    {d.demand === 'High' ? 'H' : 'M'}
                                </div>
                                <div>
                                    <p className="text-sm font-bold text-gray-900">{d.grammage} Pack</p>
                                    <p className="text-xs text-black font-medium">Search Volume Index: {d.demand === 'High' ? '92/100' : '65/100'}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- Geo Grid (Module 5A) ---
export const GeoGrid: React.FC<{ data: any[]; onIssueClick?: (city: string, issue: string) => void }> = ({ data, onIssueClick }) => {
    return (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {data.map((city, i) => (
                <div key={i} className="bg-white p-3 rounded border border-gray-200 relative overflow-hidden group hover:border-brand-accent transition-colors shadow-sm hover:shadow-md">
                    <div className="flex justify-between items-start">
                        <span className="font-bold text-gray-900">{city.city}</span>
                        <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                            city.delta < 0 ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                        }`}>
                            {city.delta > 0 ? '+' : ''}{city.delta}%
                        </span>
                    </div>
                    <div className="mt-2 text-xs text-black font-medium">
                        <p>Share: <span className="text-gray-900 font-bold">{city.share}%</span></p>
                        {city.revenueAtRisk > 0 && (
                            <p>Risk: <span className="text-red-600 font-bold">₹{(city.revenueAtRisk / 100000).toFixed(1)}L</span></p>
                        )}
                    </div>
                    {/* Primary Issue Tag */}
                    <div className="mt-3 pt-2 border-t border-gray-100 flex justify-between items-center">
                        <span className="text-[10px] uppercase text-black font-bold">Issue</span>
                        <button 
                            onClick={() => onIssueClick && onIssueClick(city.city, city.primaryIssue)}
                            className="text-[10px] text-brand-accent font-bold cursor-pointer hover:underline"
                        >
                            {city.primaryIssue} →
                        </button>
                    </div>
                    
                    {/* Background decoration for status */}
                    {city.delta < -1.0 && (
                        <div className="absolute bottom-0 left-0 w-full h-1 bg-red-500"></div>
                    )}
                </div>
            ))}
        </div>
    )
}
