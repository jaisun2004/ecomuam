
import React, { useState } from 'react';
import { FilterIcon, BellIcon, SparklesIcon } from '../icons/ModuleIcons';
import OpportunityMatrix from '../../modules/answerEngine/OpportunityMatrix';
import { CategoryMode } from '../../types';

interface HeaderProps {
    categoryMode?: CategoryMode;
    setCategoryMode?: (mode: CategoryMode) => void;
    cityFilter?: string;
    setCityFilter?: (city: string) => void;
}

const Header: React.FC<HeaderProps> = ({ 
    categoryMode = 'FMCG', 
    setCategoryMode,
    cityFilter = 'National',
    setCityFilter
}) => {
  const [isMatrixOpen, setIsMatrixOpen] = useState(false);

  return (
    <>
      <header className="h-20 bg-white flex-shrink-0 flex items-center justify-between px-4 sm:px-6 lg:px-8 border-b border-gray-200 shadow-sm z-10">
        <div className="flex items-center space-x-4">
          <button className="flex items-center space-x-2 p-2 rounded-md bg-gray-50 hover:bg-gray-100 border border-gray-200 transition-colors text-gray-700">
            <FilterIcon className="h-5 w-5 text-gray-500" />
            <span className="text-sm font-medium">Global Filters</span>
          </button>
          
          {/* Category Mode Toggle */}
          <div className="hidden md:flex bg-gray-100 border border-gray-200 rounded-lg p-1">
             <button 
                onClick={() => setCategoryMode && setCategoryMode('FMCG')}
                className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${categoryMode === 'FMCG' ? 'bg-white text-brand-accent shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
             >
                 FMCG Mode
             </button>
             <button 
                onClick={() => setCategoryMode && setCategoryMode('Electronics')}
                className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${categoryMode === 'Electronics' ? 'bg-white text-brand-accent shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
             >
                 Electronics
             </button>
          </div>

           {/* City Filter - Prominent Placement */}
           <div className="flex items-center bg-gray-50 border border-gray-200 rounded-md px-3 py-1.5 ml-2">
              <span className="text-xs font-bold text-gray-500 uppercase mr-2 tracking-wider">Geo:</span>
              <select 
                value={cityFilter}
                onChange={(e) => setCityFilter && setCityFilter(e.target.value)}
                className="bg-transparent text-sm font-bold text-gray-900 focus:outline-none cursor-pointer min-w-[100px]"
              >
                  <option value="National">National</option>
                  <option value="Mumbai">Mumbai</option>
                  <option value="Delhi NCR">Delhi NCR</option>
                  <option value="Bengaluru">Bengaluru</option>
                  <option value="Hyderabad">Hyderabad</option>
                  <option value="Chennai">Chennai</option>
                  <option value="Kolkata">Kolkata</option>
              </select>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => setIsMatrixOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 rounded-md bg-brand-accent hover:bg-blue-700 transition-colors text-white font-semibold shadow-sm hover:shadow-md"
          >
            <SparklesIcon className="h-5 w-5" />
            <span>Prioritize Opportunities</span>
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-500 hover:text-gray-700">
            <BellIcon className="h-6 w-6" />
          </button>
          <img
            className="h-10 w-10 rounded-full object-cover border border-gray-200"
            src="https://picsum.photos/100"
            alt="User avatar"
          />
        </div>
      </header>
      {isMatrixOpen && <OpportunityMatrix onClose={() => setIsMatrixOpen(false)} />}
    </>
  );
};

export default Header;
