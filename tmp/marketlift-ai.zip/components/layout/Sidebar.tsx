
import React from 'react';
import { Module } from '../../types';
import { MODULES } from '../../constants';
import { BrandIcon } from '../icons/ModuleIcons';

interface SidebarProps {
  activeModule: Module;
  setActiveModule: (module: Module) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeModule, setActiveModule }) => {
  return (
    <nav className="bg-white w-16 md:w-64 flex flex-col h-full text-gray-900 border-r border-brand-light shadow-sm">
      <div className="flex items-center justify-center md:justify-start md:px-6 h-20 border-b border-brand-light">
        <BrandIcon className="h-8 w-8 text-brand-accent" />
        <span className="hidden md:block ml-3 font-bold text-lg tracking-tight text-gray-900">MarketLift AI</span>
      </div>
      <ul className="flex-1 mt-6">
        {MODULES.map((module) => (
          <li key={module.id} className="px-3 md:px-6">
            <button
              onClick={() => setActiveModule(module)}
              className={`w-full flex items-center p-3 my-1 rounded-lg transition-colors duration-200 font-medium ${
                activeModule.id === module.id
                  ? 'bg-brand-accent/10 text-brand-accent'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <module.icon className={`h-6 w-6 ${activeModule.id === module.id ? 'text-brand-accent' : 'text-gray-400 group-hover:text-gray-500'}`} />
              <span className="hidden md:block ml-4">{module.name}</span>
            </button>
          </li>
        ))}
      </ul>
      <div className="p-6 border-t border-brand-light">
        <p className="hidden md:block text-xs text-gray-400">© 2024 MarketLift</p>
      </div>
    </nav>
  );
};

export default Sidebar;
