
import { ContentHealthScore, Opportunity, Metric, Alert, RetailerMetric, AdCampaign, CityMetric } from '../types';

export const mockContentHealthScores: ContentHealthScore[] = [
  {
    sku: "SKU-101",
    retailer: "Amazon",
    score: 65,
    titleScore: 40,
    heroImageScore: 90,
    secondaryContentScore: 70,
    descriptionScore: 80,
    reviewsScore: 95,
  },
  {
    sku: "SKU-101",
    retailer: "Blinkit",
    score: 88,
    titleScore: 90,
    heroImageScore: 80,
    secondaryContentScore: 90,
    descriptionScore: 90,
    reviewsScore: 92,
  },
  {
    sku: "SKU-205",
    retailer: "Amazon",
    score: 92,
    titleScore: 95,
    heroImageScore: 95,
    secondaryContentScore: 85,
    descriptionScore: 88,
    reviewsScore: 99,
  },
  {
    sku: "SKU-300",
    retailer: "Zepto",
    score: 52,
    titleScore: 30,
    heroImageScore: 40,
    secondaryContentScore: 60,
    descriptionScore: 70,
    reviewsScore: 91,
  },
  {
    sku: "SKU-300",
    retailer: "Amazon",
    score: 71,
    titleScore: 60,
    heroImageScore: 75,
    secondaryContentScore: 80,
    descriptionScore: 70,
    reviewsScore: 93,
  },
];

export const mockProductTitles: Record<string, string> = {
    "SKU-101": "SuperBoost Energy Drink",
    "SKU-205": "Pro-Hydrate Electrolyte Powder - Lemon Lime Flavor - 30 Servings",
    "SKU-300": "Organic Green Tea Bags",
};


export const mockOpportunities: Opportunity[] = [
    { id: '1', module: 'Market Share', description: 'Lost 2.4% share in Mumbai to "Comp A" due to aggressive price cut.', revenueImpact: 'High', easeOfFix: 'Easy' },
    { id: '2', module: 'Availability', description: 'Top-selling SKU-205 is 35% out of stock at Blinkit dark stores in NCR.', revenueImpact: 'High', easeOfFix: 'Hard' },
    { id: '3', module: 'Share of Shelf', description: 'Organic rank for "energy drink" dropped to #9. Dependency on paid spend is 85%.', revenueImpact: 'Medium', easeOfFix: 'Medium' },
    { id: '4', module: 'Ad Optimisation', description: 'Keyword "Sugar free" has high intent but 0% SOV. Competitor B owns this term.', revenueImpact: 'High', easeOfFix: 'Easy' },
    { id: '5', module: 'Content', description: 'Hero image for SKU-300 on Zepto violates background compliance.', revenueImpact: 'Medium', easeOfFix: 'Easy' },
    { id: '6', module: 'Pricing', description: 'Price gap vs Market Leader widened to 15%. Volume velocity slowed by 8%.', revenueImpact: 'High', easeOfFix: 'Easy' },
];

export const brandHealthMetrics: Metric[] = [
    { label: 'Market Share', value: '12.4%', change: '-0.8%', trend: 'down', status: 'critical' },
    { label: 'Global Availability', value: '94.2%', change: '-2.1%', trend: 'down', status: 'monitor' },
    { label: 'Share of Shelf (Org)', value: '#4', change: '-2', trend: 'down', status: 'monitor' },
    { label: 'Ad ROAS', value: '3.2x', change: '+0.4', trend: 'up', status: 'healthy' },
    { label: 'Price Index', value: '105', change: '+3.0%', trend: 'up', status: 'monitor' },
];

export const recentAlerts: Alert[] = [
    { id: 'a1', module: 'Market Share', message: 'Share in Bengaluru dropped 1.5% - Primary cause: Competitor Pricing.', severity: 'critical', timestamp: '10 min ago' },
    { id: 'a2', module: 'Availability', message: 'Critical OOS detected for SKU-205 at Blinkit - Gurugram Hub.', severity: 'critical', timestamp: '25 min ago' },
    { id: 'a3', module: 'Ads', message: 'Defensive campaign triggered for "Pro-Hydrate" due to competitor aggression.', severity: 'info', timestamp: '1 hour ago' },
];

export const oosHeatmapData = [
    { sku: 'SKU-101', retailers: [{ name: 'Amazon', status: 'ok' }, { name: 'Blinkit', status: 'ok' }, { name: 'Zepto', status: 'warning' }] },
    { sku: 'SKU-205', retailers: [{ name: 'Amazon', status: 'ok' }, { name: 'Blinkit', status: 'critical' }, { name: 'Zepto', status: 'ok' }] },
    { sku: 'SKU-300', retailers: [{ name: 'Amazon', status: 'warning' }, { name: 'Blinkit', status: 'ok' }, { name: 'Zepto', status: 'critical' }] },
];

export const lostRevenueData: RetailerMetric[] = [
    { retailer: 'Blinkit', value: 4500000, target: 0 },
    { retailer: 'Zepto', value: 1250000, target: 0 },
    { retailer: 'Amazon', value: 850000, target: 0 },
];

export const priceComplianceData = [
    { retailer: 'Amazon', violations: 0, status: 'healthy' },
    { retailer: 'Blinkit', violations: 2, status: 'monitor' },
    { retailer: 'Zepto', violations: 0, status: 'healthy' },
    { retailer: 'Swiggy Instamart', violations: 5, status: 'critical' },
];

export const shareOfSearchData = [
    { brand: 'Our Brand', value: 35, color: '#3b82f6' },
    { brand: 'Comp A', value: 25, color: '#9ca3af' },
    { brand: 'Comp B', value: 20, color: '#9ca3af' },
    { brand: 'Others', value: 20, color: '#4b5563' },
];

export const marketShareWaterfallData = [
    { label: 'Last Year', value: 100, type: 'base' },
    { label: 'Price Effect', value: -5, type: 'negative' },
    { label: 'Distribution', value: +12, type: 'positive' },
    { label: 'Velocity', value: +3, type: 'positive' },
    { label: 'Current', value: 110, type: 'total' },
];

export const adReadinessData = [
    { sku: 'SKU-101', status: 'Ready', reason: 'Healthy Metrics', availability: 98, content: 88, price: 'Parity' },
    { sku: 'SKU-205', status: 'Paused', reason: 'OOS (Blinkit)', availability: 0, content: 92, price: 'Parity' },
    { sku: 'SKU-300', status: 'Ineligible', reason: 'Content Score < 70', availability: 95, content: 52, price: 'High' },
];

export const roasHeatmapData = [
    { sku: 'SKU-101', retailers: [{ name: 'Amazon', roas: 4.5 }, { name: 'Blinkit', roas: 3.2 }, { name: 'Zepto', roas: 2.1 }] },
    { sku: 'SKU-205', retailers: [{ name: 'Amazon', roas: 5.2 }, { name: 'Blinkit', roas: 0.0 }, { name: 'Zepto', roas: 4.8 }] },
    { sku: 'SKU-300', retailers: [{ name: 'Amazon', roas: 2.5 }, { name: 'Blinkit', roas: 1.8 }, { name: 'Zepto', roas: 1.5 }] },
];

export const keywordGapData = [
    { keyword: 'Sugar free energy', myShare: 5, compShare: 45, volume: 'High' },
    { keyword: 'Electrolyte powder', myShare: 35, compShare: 20, volume: 'High' },
    { keyword: 'Instant energy delivery', myShare: 10, compShare: 60, volume: 'Medium' },
    { keyword: 'Organic tea', myShare: 15, compShare: 30, volume: 'Medium' },
];

export const cannibalisationData = [
    { keyword: 'Energy Drink', organicRank: 1, sponsoredRank: 1, cpc: 120 },
    { keyword: 'Hydration', organicRank: 5, sponsoredRank: 2, cpc: 85 },
    { keyword: 'Green Tea', organicRank: 12, sponsoredRank: 3, cpc: 45 },
    { keyword: 'Electrolytes', organicRank: 2, sponsoredRank: 1, cpc: 95 },
];

export const shareOfShelfData = {
    organicRanks: [
        { brand: 'Our Brand', rank: 4, change: -2, color: '#3b82f6' },
        { brand: 'Comp A', rank: 2, change: 1, color: '#ef4444' },
        { brand: 'Comp B', rank: 5, change: 0, color: '#9ca3af' },
    ],
    sponsoredRanks: [
        { brand: 'Our Brand', rank: 1, change: 0, color: '#3b82f6' },
        { brand: 'Comp A', rank: 3, change: -1, color: '#ef4444' },
        { brand: 'Comp B', rank: 2, change: 2, color: '#9ca3af' },
    ],
    shareBreakdown: [
        { type: 'Organic', value: 35, color: '#3b82f6' },
        { type: 'Sponsored', value: 65, color: '#a855f7' },
    ]
};

export const cityShareData: CityMetric[] = [
    { city: 'National (Amazon)', region: 'India', share: 15.5, delta: -3.2, revenueAtRisk: 4500000, primaryIssue: 'Pricing' },
    { city: 'Mumbai (Blinkit)', region: 'West', share: 14.2, delta: -2.4, revenueAtRisk: 1200000, primaryIssue: 'Competitor' },
    { city: 'Delhi NCR (Blinkit)', region: 'North', share: 18.5, delta: 0.5, revenueAtRisk: 0, primaryIssue: 'Availability' },
    { city: 'Bengaluru (Blinkit)', region: 'South', share: 9.1, delta: -1.5, revenueAtRisk: 850000, primaryIssue: 'Pricing' },
    { city: 'Hyderabad (Blinkit)', region: 'South', share: 11.0, delta: 0.2, revenueAtRisk: 0, primaryIssue: 'Content' },
    { city: 'Chennai (Blinkit)', region: 'South', share: 8.4, delta: -0.1, revenueAtRisk: 150000, primaryIssue: 'Availability' },
    { city: 'Kolkata (Blinkit)', region: 'East', share: 6.2, delta: 1.1, revenueAtRisk: 0, primaryIssue: 'Content' },
];
