
import { Module } from './types';
import { AvailabilityIcon, PricingIcon, ShareOfShelfIcon, ContentAuditIcon, MarketShareIcon, AdOptimisationIcon, LightBulbIcon } from './components/icons/ModuleIcons';

export const MODULES: Module[] = [
  { id: 'market-share', name: 'Market Share', icon: MarketShareIcon },
  { id: 'ad-optimisation', name: 'Ad Optimisation', icon: AdOptimisationIcon },
  { id: 'availability', name: 'Availability', icon: AvailabilityIcon },
  { id: 'pricing', name: 'Pricing', icon: PricingIcon },
  { id: 'share-of-shelf', name: 'Share of Shelf', icon: ShareOfShelfIcon },
  { id: 'content-audit', name: 'Content Audit', icon: ContentAuditIcon },
  { id: 'category-recommendation', name: 'Category Recs (NPD)', icon: LightBulbIcon },
];

export const CONTENT_SCORING_WEIGHTS = {
  title: 0.30,
  heroImage: 0.25,
  secondaryImages: 0.15,
  bulletPoints: 0.15,
  description: 0.10,
  ratings: 0.05,
};
