
import React from 'react';

export interface Module {
  id: string;
  name: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export type CategoryMode = 'FMCG' | 'Electronics';

export interface ContentHealthScore {
  sku: string;
  retailer: string;
  score: number;
  titleScore: number;
  heroImageScore: number;
  secondaryContentScore: number;
  descriptionScore: number;
  reviewsScore: number;
}

export type Opportunity = {
  id: string;
  module: string;
  description: string;
  revenueImpact: 'High' | 'Medium' | 'Low';
  easeOfFix: 'Easy' | 'Medium' | 'Hard';
};

export type OpportunityClassification = {
  id: string;
  revenueImpact: 'High' | 'Low';
  easeOfFix: 'Easy' | 'Hard';
}

export interface Metric {
  label: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'flat';
  status: 'healthy' | 'monitor' | 'critical';
}

export interface Alert {
  id: string;
  module: string;
  message: string;
  severity: 'critical' | 'warning' | 'info';
  timestamp: string;
}

export interface RetailerMetric {
    retailer: string;
    value: number;
    target: number;
}

export interface AdCampaign {
    id: string;
    name: string;
    platform: string;
    status: 'Active' | 'Paused' | 'Archived';
    roas: number;
    spend: number;
    reason?: string; // e.g., "Paused due to OOS"
}

export interface CityMetric {
    city: string;
    region: string;
    share: number;
    delta: number;
    revenueAtRisk: number;
    primaryIssue: 'Availability' | 'Pricing' | 'Content' | 'Competitor';
}
