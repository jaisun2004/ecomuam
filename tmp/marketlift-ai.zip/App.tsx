
import React, { useState } from 'react';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import BrandHealthSummary from './components/dashboard/BrandHealthSummary';
import AnomalyFeed from './components/dashboard/AnomalyFeed';
import AnalyticalDashboard from './components/dashboard/AnalyticalDashboard';
import AvailabilityView from './modules/availability/AvailabilityView';
import PricingView from './modules/pricing/PricingView';
import ShareOfShelfView from './modules/shareOfShelf/ShareOfShelfView';
import ContentAuditView from './modules/contentAudit/ContentAuditView';
import MarketShareView from './modules/marketShare/MarketShareView';
import AdOptimisationView from './modules/adOptimisation/AdOptimisationView';
import CategoryRecommendationView from './modules/categoryRecommendation/CategoryRecommendationView';
import { Module, CategoryMode } from './types';
import { MODULES } from './constants';
import { TableCellsIcon } from './components/icons/ModuleIcons';

const App: React.FC = () => {
  const [activeModule, setActiveModule] = useState<Module>(MODULES[0]); // Default to Market Share (index 0 now)
  const [categoryMode, setCategoryMode] = useState<CategoryMode>('FMCG');
  const [cityFilter, setCityFilter] = useState<string>('National');
  const [isDeepDiveOpen, setIsDeepDiveOpen] = useState(false);

  const renderActiveModule = () => {
    switch (activeModule.id) {
      case 'availability':
        return <AvailabilityView />;
      case 'pricing':
        return <PricingView />;
      case 'share-of-shelf':
        return <ShareOfShelfView />;
      case 'content-audit':
        return <ContentAuditView />;
      case 'market-share':
        return <MarketShareView categoryMode={categoryMode} />;
      case 'ad-optimisation':
        return <AdOptimisationView />;
      case 'category-recommendation':
        return <CategoryRecommendationView />;
      default:
        return <MarketShareView categoryMode={categoryMode} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 font-sans text-gray-900">
      <Sidebar 
        activeModule={activeModule} 
        setActiveModule={(m) => {
            setActiveModule(m);
            setIsDeepDiveOpen(false); // Reset deep dive when changing modules
        }} 
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
            categoryMode={categoryMode} 
            setCategoryMode={setCategoryMode}
            cityFilter={cityFilter}
            setCityFilter={setCityFilter}
        />
        <BrandHealthSummary />
        <div className="flex-1 flex overflow-hidden">
            {isDeepDiveOpen ? (
                <main className="flex-1 overflow-hidden h-full">
                    <AnalyticalDashboard activeModule={activeModule} onClose={() => setIsDeepDiveOpen(false)} />
                </main>
            ) : (
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-4 sm:p-6 lg:p-8">
                    <div className="container mx-auto pb-12">
                        <div className="mb-6 flex justify-between items-end">
                            <div>
                                <h1 className="text-3xl font-bold text-gray-900">{activeModule.name}</h1>
                                <p className="text-gray-500 mt-1">
                                    Insights and actions for {activeModule.name.toLowerCase()} 
                                    {cityFilter !== 'National' && ` in ${cityFilter}`}.
                                </p>
                            </div>
                            <button 
                                onClick={() => setIsDeepDiveOpen(true)}
                                className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-200 hover:border-brand-accent text-gray-700 rounded-lg transition-all shadow-sm hover:shadow-md"
                            >
                                <TableCellsIcon className="w-5 h-5 text-brand-accent" />
                                <span className="font-semibold text-sm">Deep Dive Analytics</span>
                            </button>
                        </div>
                        {renderActiveModule()}
                    </div>
                </main>
            )}
            {!isDeepDiveOpen && (
                <div className="hidden xl:block">
                    <AnomalyFeed />
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default App;
