
import React, { useState } from 'react';
import Card from '../../components/shared/Card';
import { WaterfallChart, DiagnosticTree, GeoGrid } from '../../components/shared/Visuals';
import { marketShareWaterfallData, cityShareData } from '../../data/mockData';
import { CategoryMode } from '../../types';

interface MarketShareViewProps {
    categoryMode: CategoryMode;
}

const MarketShareView: React.FC<MarketShareViewProps> = ({ categoryMode }) => {
  const [activeTab, setActiveTab] = useState<'where' | 'who' | 'why' | 'synthesis'>('where');

  return (
    <div className="space-y-6">
        
        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg border border-gray-200 inline-flex mb-2">
            {[
                { id: 'where', label: '5A - WHERE did I lose?' },
                { id: 'who', label: '5B - WHO took it?' },
                { id: 'why', label: '5C - WHY (Root Cause)?' },
                { id: 'synthesis', label: '5D - Synthesis' }
            ].map(tab => (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                        activeTab === tab.id 
                        ? 'bg-white text-brand-accent shadow-sm' 
                        : 'text-gray-600 hover:text-black hover:bg-gray-200'
                    }`}
                >
                    {tab.label}
                </button>
            ))}
        </div>

        {/* 5A - WHERE */}
        {activeTab === 'where' && (
            <div className="space-y-6 animate-fadeIn">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2">
                         <Card title="Market Share by City" subtitle="Which cities are losing share right now?">
                             <GeoGrid 
                                data={cityShareData} 
                                onIssueClick={(city, issue) => {
                                    alert(`Analyzing ${issue} issue in ${city}...`);
                                    setActiveTab('why');
                                }}
                             />
                             <div className="mt-4 flex justify-end">
                                 <button className="text-xs text-brand-accent hover:text-blue-700 flex items-center font-bold">
                                     Trigger Geo-Targeted DSP Campaign for Mumbai
                                     <svg className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                                 </button>
                             </div>
                         </Card>
                    </div>
                    <Card title="SKU-Level Decomposition" subtitle="Which specific SKU is driving the loss?">
                        <div className="space-y-3">
                            <div className="flex justify-between items-center p-3 bg-gray-50 rounded border-l-4 border-green-500 border border-gray-200 shadow-sm">
                                <span className="text-xs text-gray-900 font-bold">SKU-101 (Energy)</span>
                                <span className="text-xs font-bold text-green-600">+0.2%</span>
                            </div>
                            <div className="flex justify-between items-center p-3 bg-gray-50 rounded border-l-4 border-red-500 border border-gray-200 shadow-sm">
                                <span className="text-xs text-gray-900 font-bold">SKU-205 (Hydrate)</span>
                                <span className="text-xs font-bold text-red-600">-1.8%</span>
                            </div>
                            <div className="flex justify-between items-center p-3 bg-gray-50 rounded border-l-4 border-gray-500 border border-gray-200 shadow-sm">
                                <span className="text-xs text-black font-bold">SKU-300 (Tea)</span>
                                <span className="text-xs font-bold text-black">0.0%</span>
                            </div>
                        </div>
                        <div className="mt-6 p-3 bg-blue-50 rounded border border-blue-100">
                            <p className="text-[10px] text-blue-600 uppercase font-bold tracking-wider">Insight</p>
                            <p className="text-sm text-black mt-1">
                                Share loss is concentrated in <span className="font-bold text-black">Mumbai</span> on <span className="font-bold text-black">SKU-205</span>.
                            </p>
                        </div>
                    </Card>
                </div>
            </div>
        )}

        {/* 5B - WHO */}
        {activeTab === 'who' && (
             <div className="space-y-6 animate-fadeIn">
                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                     <Card title="Competitor Share Movement" subtitle="Which competitor is growing at my expense?">
                         <div className="h-64 flex items-end relative px-4">
                             {/* Stylized Stacked Area Representation */}
                             <div className="absolute bottom-0 left-0 right-0 h-full bg-gray-50 rounded border-b border-l border-gray-200 overflow-hidden">
                                 <svg viewBox="0 0 100 50" className="w-full h-full" preserveAspectRatio="none">
                                     <path d="M0,50 L0,30 Q25,25 50,28 T100,20 L100,50 Z" fill="#3b82f6" opacity="0.6" /> {/* Me */}
                                     <path d="M0,30 Q25,25 50,28 T100,20 L100,0 L0,0 Z" fill="#9ca3af" opacity="0.3" /> {/* Others */}
                                     <path d="M0,20 Q40,25 60,15 T100,5 L100,0 L0,0 Z" fill="#ef4444" opacity="0.7" /> {/* Comp A Aggressive */}
                                 </svg>
                             </div>
                             <div className="absolute top-2 right-4 text-xs font-bold text-red-600 bg-white/80 px-2 py-1 rounded shadow-sm">Comp A (+2.4%)</div>
                             <div className="absolute bottom-4 right-4 text-xs font-bold text-blue-600 bg-white/80 px-2 py-1 rounded shadow-sm">Me (-0.8%)</div>
                         </div>
                     </Card>
                     <Card title="Pricing Aggression Detector" subtitle="Did a price cut cause this share shift?">
                         <div className="space-y-4">
                             <div className="flex items-center space-x-4">
                                 <div className="w-12 text-xs text-black font-medium">Week 1</div>
                                 <div className="flex-1 h-2 bg-gray-200 rounded"><div className="w-[10%] h-full bg-gray-400"></div></div>
                             </div>
                             <div className="flex items-center space-x-4">
                                 <div className="w-12 text-xs text-black font-medium">Week 2</div>
                                 <div className="flex-1 h-2 bg-gray-200 rounded"><div className="w-[10%] h-full bg-gray-400"></div></div>
                             </div>
                             <div className="flex items-center space-x-4">
                                 <div className="w-12 text-xs text-black font-medium">Week 3</div>
                                 <div className="flex-1 h-2 bg-gray-200 rounded relative">
                                     <div className="w-[40%] h-full bg-red-500"></div>
                                     <span className="absolute -top-6 left-[20%] text-[10px] bg-red-100 text-red-700 border border-red-200 px-1 rounded font-bold whitespace-nowrap">Comp A Price Cut -15%</span>
                                 </div>
                             </div>
                              <div className="flex items-center space-x-4">
                                 <div className="w-12 text-xs text-black font-bold">Today</div>
                                 <div className="flex-1 h-2 bg-gray-200 rounded"><div className="w-[45%] h-full bg-red-500"></div></div>
                             </div>
                             <button className="w-full mt-4 py-2 bg-brand-accent text-sm text-white rounded hover:bg-blue-700 font-bold shadow-sm transition-colors">
                                 Model Response in Pricing Simulator
                             </button>
                         </div>
                     </Card>
                 </div>
             </div>
        )}

        {/* 5C - WHY */}
        {activeTab === 'why' && (
            <div className="space-y-6 animate-fadeIn">
                 <Card title="Root Cause Diagnostic Tree" subtitle="Why did share drop in Mumbai?">
                     <DiagnosticTree />
                 </Card>
                 
                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                     <div className="lg:col-span-2">
                         <Card title="Market Share Waterfall" subtitle="Drivers of Change">
                             <WaterfallChart data={marketShareWaterfallData} />
                         </Card>
                     </div>
                     <Card title="Category Context" subtitle={`Is ${categoryMode} category growing?`}>
                         <div className="flex flex-col items-center justify-center h-full space-y-4">
                             <div className="text-center">
                                 <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Category Growth</p>
                                 <p className="text-3xl font-bold text-green-600">+5.2%</p>
                             </div>
                             <div className="text-center">
                                 <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">My Growth</p>
                                 <p className="text-3xl font-bold text-red-600">-0.8%</p>
                             </div>
                             <p className="text-xs text-gray-600 text-center px-4 bg-gray-50 p-2 rounded border border-gray-100">
                                 You are underperforming the category. This is a share loss problem, not a category slowdown.
                             </p>
                         </div>
                     </Card>
                 </div>
            </div>
        )}

        {/* 5D - Synthesis */}
        {activeTab === 'synthesis' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fadeIn">
                <Card title="Share Recovery Prioritisation" subtitle="Where to focus first?">
                     <div className="relative h-64 bg-gray-50 rounded border border-gray-200">
                         <div className="absolute inset-0 flex items-center justify-center">
                             <div className="w-[90%] h-[90%] grid grid-cols-2 grid-rows-2 gap-1">
                                 <div className="bg-red-50 border border-red-200 p-2 relative group hover:bg-red-100 cursor-pointer transition-colors">
                                     <span className="text-[10px] text-red-700 font-bold">HIGH LOSS / EASY FIX</span>
                                     <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center w-full">
                                         <p className="text-gray-900 font-bold">Mumbai / Pricing</p>
                                         <p className="text-xs text-red-600 font-bold">Risk: ₹12L</p>
                                     </div>
                                 </div>
                                  <div className="bg-amber-50 border border-amber-200 p-2 relative">
                                     <span className="text-[10px] text-amber-700 font-bold">HIGH LOSS / HARD FIX</span>
                                     <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center w-full">
                                          <p className="text-black text-xs font-medium">NCR / Availability</p>
                                     </div>
                                 </div>
                                 <div className="bg-blue-50 border border-blue-200 p-2">
                                     <span className="text-[10px] text-blue-700 font-bold">LOW LOSS / EASY FIX</span>
                                 </div>
                                 <div className="bg-gray-100 border border-gray-200 p-2">
                                      <span className="text-[10px] text-black font-bold">LOW LOSS / HARD FIX</span>
                                 </div>
                             </div>
                         </div>
                     </div>
                </Card>
                <Card title="Ad Optimisation Handoff" subtitle="Automated Response Brief">
                    <div className="space-y-4">
                        <div className="p-4 bg-white border-l-4 border-red-500 rounded border border-gray-200 shadow-sm">
                            <h4 className="text-sm font-bold text-black">1. Defensive Pricing Ad Strategy</h4>
                            <p className="text-xs text-black mt-1">
                                Trigger defensive sponsored placement on SKU-205 in Mumbai to counter Comp A pricing.
                            </p>
                            <button className="mt-3 text-xs bg-brand-accent text-white px-3 py-1.5 rounded font-bold hover:bg-blue-700 transition-colors shadow-sm">
                                Activate Campaign
                            </button>
                        </div>
                        <div className="p-4 bg-white border-l-4 border-amber-500 rounded border border-gray-200 shadow-sm">
                            <h4 className="text-sm font-bold text-black">2. Geo-Targeted Awareness</h4>
                            <p className="text-xs text-black mt-1">
                                Launch DSP campaign in Mumbai targeting lapsed users of SKU-205.
                            </p>
                        </div>
                    </div>
                </Card>
            </div>
        )}
    </div>
  );
};

export default MarketShareView;
