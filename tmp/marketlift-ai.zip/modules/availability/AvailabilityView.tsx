
import React from 'react';
import Card from '../../components/shared/Card';
import { oosHeatmapData, lostRevenueData } from '../../data/mockData';
import { StatusBadge, SimpleBarChart } from '../../components/shared/Visuals';

const AvailabilityView: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* OOS Heatmap */}
      <div className="lg:col-span-2">
        <Card title="OOS Heatmap" subtitle="Which SKUs are out of stock at which retailers?">
            <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr>
                            <th className="p-3 text-sm text-gray-500 font-bold border-b border-gray-200">SKU</th>
                            {oosHeatmapData[0].retailers.map((r, i) => (
                                <th key={i} className="p-3 text-sm text-gray-500 font-bold border-b border-gray-200 text-center">{r.name}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {oosHeatmapData.map((row, i) => (
                            <tr key={i} className="border-b border-gray-100 last:border-0 hover:bg-gray-50 transition-colors">
                                <td className="p-3 text-sm font-mono text-gray-700 font-medium">{row.sku}</td>
                                {row.retailers.map((r, j) => (
                                    <td key={j} className="p-3 text-center">
                                        <div className={`h-4 w-4 rounded-sm mx-auto ${
                                            r.status === 'ok' ? 'bg-green-500' : 
                                            r.status === 'warning' ? 'bg-amber-500' : 'bg-red-500 animate-pulse'
                                        }`} title={r.status}></div>
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
      </div>

      {/* Lost Revenue Estimator */}
      <Card title="Lost Revenue Estimator" subtitle="How much revenue is being lost to OOS?">
         <div className="flex flex-col justify-center h-full">
            <div className="text-center mb-6">
                <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">Total Est. Loss (4W)</p>
                <p className="text-4xl font-bold text-red-600 mt-2">₹66,00,000</p>
            </div>
            <div className="space-y-3">
                {lostRevenueData.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-200 shadow-sm">
                        <span className="text-sm text-gray-700 font-medium">{item.retailer}</span>
                        <span className="text-sm font-bold text-red-600">-₹{item.value.toLocaleString('en-IN')}</span>
                    </div>
                ))}
            </div>
             <button className="mt-6 w-full py-2 bg-brand-accent text-white rounded font-bold hover:bg-blue-700 transition-colors text-sm shadow-sm">
                 Trigger Restock Workflow
             </button>
        </div>
      </Card>

      {/* OOS Trend Line Placeholder using simple SVG */}
      <div className="lg:col-span-2">
          <Card title="OOS Trend Line (Last 4 Weeks)" subtitle="Is availability improving or degrading?">
             <div className="h-64 flex items-end space-x-1 px-4 pt-4">
                 {[...Array(28)].map((_, i) => {
                     const h = Math.random() * 80 + 20;
                     return (
                        <div key={i} className="flex-1 bg-blue-100 hover:bg-brand-accent transition-colors rounded-t" style={{ height: `${h}%` }}></div>
                     )
                 })}
             </div>
             <div className="flex justify-between text-xs text-gray-400 font-medium mt-2 px-4 uppercase tracking-wide">
                 <span>4 weeks ago</span>
                 <span>Today</span>
             </div>
          </Card>
      </div>
      
      {/* Restock Lag */}
      <Card title="Restock Lag Indicator" subtitle="Avg. days/hours to recover stock">
         <div className="space-y-4">
            <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 font-medium">Blinkit (NCR)</span>
                <div className="flex items-center space-x-2">
                    <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-red-500 w-[80%]"></div>
                    </div>
                    <span className="text-sm font-bold text-red-600">4 hours</span>
                </div>
            </div>
            <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 font-medium">Amazon</span>
                <div className="flex items-center space-x-2">
                    <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-green-500 w-[20%]"></div>
                    </div>
                    <span className="text-sm font-bold text-green-600">1.2 days</span>
                </div>
            </div>
            <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 font-medium">Zepto</span>
                <div className="flex items-center space-x-2">
                    <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-500 w-[50%]"></div>
                    </div>
                    <span className="text-sm font-bold text-amber-600">2 hours</span>
                </div>
            </div>
         </div>
      </Card>
    </div>
  );
};

export default AvailabilityView;
