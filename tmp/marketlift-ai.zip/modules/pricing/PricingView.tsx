
import React, { useState } from 'react';
import Card from '../../components/shared/Card';
import { StatusBadge } from '../../components/shared/Visuals';

const PricingView: React.FC = () => {
  const [selectedElasticitySku, setSelectedElasticitySku] = useState<'SKU-101' | 'SKU-205'>('SKU-101');

  // Mock data specifically for the 3-bucket logic
  const pricingActions = [
      {
          type: 'COMPETITIVE',
          title: 'Price Competitive',
          subtitle: 'Index < 98 vs. Market',
          skus: ['SKU-101 (Energy)', 'SKU-404 (Bar)'],
          recommendation: 'Increase Bids (+15%) to capture demand.',
          actionLabel: 'Boost Bids',
          status: 'ok'
      },
      {
          type: 'UNCOMPETITIVE',
          title: 'Price Uncompetitive',
          subtitle: 'Index > 110 vs. Market',
          skus: ['SKU-300 (Tea)', 'SKU-505 (Mix)'],
          recommendation: 'Reduce Bids (-25%) to protect margin.',
          actionLabel: 'Reduce Spend',
          status: 'warning'
      },
      {
          type: 'DEFENSIVE',
          title: 'Competitor Price Cut',
          subtitle: 'Comp A dropped >15%',
          skus: ['SKU-205 (Hydrate)'],
          recommendation: 'Trigger defensive ad placement.',
          actionLabel: 'Defend Now',
          status: 'critical'
      }
  ];

  // Elasticity Data
  const elasticityData = {
      'SKU-101': [
          { price: -20, volume: 48, confidence: 5 },
          { price: -15, volume: 32, confidence: 4 },
          { price: -10, volume: 18, confidence: 3 },
          { price: -5, volume: 8, confidence: 2 },
          { price: 0, volume: 0, confidence: 0 },
          { price: 5, volume: -12, confidence: 3 },
          { price: 10, volume: -28, confidence: 5 },
          { price: 15, volume: -45, confidence: 7 },
          { price: 20, volume: -60, confidence: 9 },
      ],
      'SKU-205': [
          { price: -20, volume: 25, confidence: 6 }, 
          { price: -15, volume: 18, confidence: 5 },
          { price: -10, volume: 12, confidence: 4 },
          { price: -5, volume: 5, confidence: 2 },
          { price: 0, volume: 0, confidence: 0 },
          { price: 5, volume: -4, confidence: 2 },
          { price: 10, volume: -10, confidence: 4 },
          { price: 15, volume: -18, confidence: 6 },
          { price: 20, volume: -28, confidence: 8 },
      ]
  };

  const currentElasticity = elasticityData[selectedElasticitySku];

  return (
    <div className="space-y-6">
        {/* PRIMARY ACTION LAYER: The 3 Buckets */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {pricingActions.map((item, idx) => (
                <div key={idx} className={`rounded-lg border p-6 flex flex-col justify-between h-full shadow-sm ${
                    item.type === 'COMPETITIVE' ? 'bg-green-50 border-green-200' :
                    item.type === 'UNCOMPETITIVE' ? 'bg-amber-50 border-amber-200' :
                    'bg-red-50 border-red-200'
                }`}>
                    <div>
                        <div className="flex justify-between items-start mb-2">
                             <h3 className={`text-lg font-bold ${
                                 item.type === 'COMPETITIVE' ? 'text-green-900' :
                                 item.type === 'UNCOMPETITIVE' ? 'text-amber-900' :
                                 'text-red-900'
                             }`}>{item.title}</h3>
                             <StatusBadge status={item.status as any} />
                        </div>
                        <p className="text-sm text-gray-600 mb-4 font-medium">{item.subtitle}</p>
                        
                        <div className="bg-white rounded p-3 mb-4 border border-gray-200 shadow-sm">
                            <p className="text-xs text-gray-500 uppercase mb-2 font-bold tracking-wider">Affected SKUs</p>
                            <ul className="space-y-1">
                                {item.skus.map(sku => (
                                    <li key={sku} className="text-sm text-gray-700 font-mono font-medium">• {sku}</li>
                                ))}
                            </ul>
                        </div>
                        
                        <p className="text-sm font-bold text-gray-900 mb-2">
                            Strategy: <span className="text-gray-600 font-normal">{item.recommendation}</span>
                        </p>
                    </div>
                    
                    <button className={`w-full py-2 rounded font-bold text-sm uppercase transition-colors mt-4 shadow-sm ${
                        item.type === 'COMPETITIVE' ? 'bg-green-600 hover:bg-green-700 text-white' :
                        item.type === 'UNCOMPETITIVE' ? 'bg-amber-600 hover:bg-amber-700 text-white' :
                        'bg-red-600 hover:bg-red-700 text-white'
                    }`}>
                        {item.actionLabel}
                    </button>
                </div>
            ))}
        </div>

        {/* ELASTICITY & SIMULATOR ROW */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Price Elasticity Curve */}
            <div className="lg:col-span-2">
                <Card title="Price Elasticity Curve" subtitle="Relationship between price changes and sales volume (with 95% confidence)">
                    <div className="flex justify-end mb-4">
                        <div className="bg-gray-100 rounded p-1 flex space-x-1 border border-gray-200">
                            {['SKU-101', 'SKU-205'].map(sku => (
                                <button 
                                    key={sku}
                                    onClick={() => setSelectedElasticitySku(sku as any)}
                                    className={`px-3 py-1 text-xs font-bold rounded transition-colors ${selectedElasticitySku === sku ? 'bg-white text-brand-accent shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
                                >
                                    {sku}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="h-64 w-full relative bg-gray-50 rounded border border-gray-200 p-4">
                        {/* SVG Chart */}
                        <svg className="w-full h-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
                            {/* Axes */}
                            <line x1="0" y1="50" x2="100" y2="50" stroke="#cbd5e1" strokeWidth="0.5" strokeDasharray="2" /> {/* X Axis (0 volume) */}
                            <line x1="50" y1="0" x2="50" y2="100" stroke="#cbd5e1" strokeWidth="0.5" strokeDasharray="2" /> {/* Y Axis (0 price) */}
                            
                            <text x="5" y="5" fontSize="3" fill="#64748b" fontWeight="bold">+Vol</text>
                            <text x="5" y="95" fontSize="3" fill="#64748b" fontWeight="bold">-Vol</text>
                            <text x="95" y="48" fontSize="3" fill="#64748b" fontWeight="bold">+Price</text>
                            <text x="5" y="48" fontSize="3" fill="#64748b" fontWeight="bold">-Price</text>

                            {/* Confidence Band */}
                            <path 
                                d={`
                                    M ${currentElasticity.map(d => {
                                        const x = ((d.price + 25) / 50) * 100;
                                        const y = 50 - ((d.volume + d.confidence) / 100) * 80; // Scale vol
                                        return `${x},${y}`;
                                    }).join(' L ')}
                                    L ${currentElasticity.slice().reverse().map(d => {
                                        const x = ((d.price + 25) / 50) * 100;
                                        const y = 50 - ((d.volume - d.confidence) / 100) * 80;
                                        return `${x},${y}`;
                                    }).join(' L ')}
                                    Z
                                `}
                                fill="rgba(37, 99, 235, 0.1)"
                                stroke="none"
                            />

                            {/* Main Curve */}
                            <path 
                                d={`M ${currentElasticity.map(d => {
                                    const x = ((d.price + 25) / 50) * 100;
                                    const y = 50 - (d.volume / 100) * 80;
                                    return `${x},${y}`;
                                }).join(' L ')}`}
                                fill="none"
                                stroke="#2563eb"
                                strokeWidth="1.5"
                            />
                            
                            {/* Points */}
                            {currentElasticity.map((d, i) => {
                                const x = ((d.price + 25) / 50) * 100;
                                const y = 50 - (d.volume / 100) * 80;
                                return (
                                    <circle key={i} cx={x} cy={y} r="1.5" fill="#ffffff" stroke="#2563eb" strokeWidth="1" className="hover:r-2 transition-all" />
                                );
                            })}
                        </svg>
                        
                        {/* Tooltip Overlay (Mock) */}
                        <div className="absolute bottom-2 right-2 text-xs bg-white/90 p-2 rounded border border-gray-200 shadow-sm backdrop-blur-sm">
                            <span className="text-gray-500 font-medium">Elasticity Coeff: </span>
                            <span className={`font-bold ${selectedElasticitySku === 'SKU-101' ? 'text-red-600' : 'text-green-600'}`}>
                                {selectedElasticitySku === 'SKU-101' ? '-2.4 (High)' : '-1.1 (Low)'}
                            </span>
                        </div>
                    </div>
                </Card>
            </div>

            {/* Reactive Simulator */}
            <Card title="Scenario Simulator" subtitle={`Project outcomes for ${selectedElasticitySku}`}>
                 <div className="flex flex-col h-full justify-center space-y-6">
                     <div className="space-y-4">
                         <div>
                             <div className="flex justify-between text-sm mb-2">
                                 <span className="text-gray-500 font-medium">Proposed Price Change</span>
                                 <span className="text-gray-900 font-bold">-10%</span>
                             </div>
                             {/* Slider Mock */}
                             <div className="w-full bg-gray-200 h-2 rounded-full relative">
                                 <div className="absolute top-1/2 left-[30%] w-4 h-4 bg-white border border-gray-300 rounded-full -translate-y-1/2 shadow cursor-pointer hover:scale-110 transition-transform"></div>
                                 <div className="w-[30%] bg-blue-500 h-2 rounded-l-full"></div>
                             </div>
                             <div className="flex justify-between text-xs text-gray-400 mt-1 font-medium">
                                 <span>-20%</span>
                                 <span>+20%</span>
                             </div>
                         </div>
                     </div>
                     
                     <div className="grid grid-cols-2 gap-4">
                         <div className="bg-gray-50 p-3 rounded text-center border border-gray-200">
                             <p className="text-xs text-gray-500 uppercase font-bold tracking-wider">Est. Volume</p>
                             <p className={`text-xl font-bold ${selectedElasticitySku === 'SKU-101' ? 'text-green-600' : 'text-green-500'}`}>
                                 {selectedElasticitySku === 'SKU-101' ? '+18%' : '+12%'}
                             </p>
                         </div>
                         <div className="bg-gray-50 p-3 rounded text-center border border-gray-200">
                             <p className="text-xs text-gray-500 uppercase font-bold tracking-wider">Est. Margin</p>
                             <p className="text-xl font-bold text-red-600">-4%</p>
                         </div>
                     </div>

                     <div className="text-xs text-gray-400 italic text-center">
                         *Based on elasticity data for {selectedElasticitySku}
                     </div>

                     <button className="w-full py-2 border border-brand-accent text-brand-accent hover:bg-brand-accent hover:text-white rounded transition-colors text-sm font-bold shadow-sm">
                         Apply to Forecast
                     </button>
                 </div>
            </Card>
        </div>

        {/* TRENDS ROW */}
        <div className="w-full">
             <Card title="Competitive Price Index Trend" subtitle="Avg. Price vs. Competitors (Index 100)">
                <div className="h-64 relative border-l border-b border-gray-200 m-2">
                     {/* Mock Chart Area */}
                     <div className="absolute inset-0 flex items-end">
                         <svg className="w-full h-full overflow-visible" preserveAspectRatio="none">
                             {/* Grid Lines */}
                             <line x1="0" y1="20%" x2="100%" y2="20%" stroke="#e2e8f0" strokeDasharray="4"/>
                             <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#e2e8f0" strokeDasharray="4"/>
                             <line x1="0" y1="80%" x2="100%" y2="80%" stroke="#94a3b8" strokeWidth="2" strokeDasharray="4"/> {/* Index 100 Line */}
                             
                             {/* Data Line */}
                             <polyline 
                                points="0,180 50,170 100,160 150,190 200,175 250,150 300,160 350,140 400,130 450,140 500,120" 
                                fill="none" 
                                stroke="#2563eb" 
                                strokeWidth="3"
                             />
                         </svg>
                     </div>
                     <div className="absolute top-[20%] right-0 text-xs text-gray-400 font-medium">120</div>
                     <div className="absolute top-[50%] right-0 text-xs text-gray-400 font-medium">110</div>
                     <div className="absolute top-[80%] right-0 text-xs text-gray-600 bg-gray-100 px-1 rounded font-bold border border-gray-200">100</div>
                </div>
                <div className="flex justify-center space-x-6 mt-4">
                     <div className="flex items-center text-xs text-gray-600 font-medium">
                         <span className="w-3 h-3 bg-brand-accent rounded-full mr-2"></span> Our Brand
                     </div>
                     <div className="flex items-center text-xs text-gray-600 font-medium">
                         <span className="w-3 h-3 bg-gray-400 rounded-full mr-2"></span> Category Avg
                     </div>
                </div>
            </Card>
        </div>
    </div>
  );
};

export default PricingView;
