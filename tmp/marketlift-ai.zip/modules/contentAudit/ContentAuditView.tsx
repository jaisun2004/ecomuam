
import React from 'react';
import TitleOptimisationHeatmap from './TitleOptimisationHeatmap';
import Card from '../../components/shared/Card';
import { SimpleBarChart } from '../../components/shared/Visuals';

const ContentAuditView: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
             <h3 className="text-black text-xs font-bold uppercase">Avg Content Score</h3>
             <div className="flex items-end mt-2 space-x-2">
                 <span className="text-3xl font-bold text-gray-900">72</span>
                 <span className="text-sm text-green-600 mb-1">Good</span>
             </div>
             <div className="w-full bg-gray-200 h-1.5 rounded-full mt-2">
                 <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '72%' }}></div>
             </div>
         </div>
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
             <h3 className="text-black text-xs font-bold uppercase">SEO Health (Keywords)</h3>
             <span className="text-2xl font-bold text-amber-500 mt-1 block">64/100</span>
             <p className="text-xs text-black mt-1">Missing high-volume terms</p>
         </div>
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
             <h3 className="text-black text-xs font-bold uppercase">Hero Images (25%)</h3>
             <span className="text-2xl font-bold text-green-500 mt-1 block">88/100</span>
         </div>
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
             <h3 className="text-black text-xs font-bold uppercase">Description (10%)</h3>
             <span className="text-2xl font-bold text-blue-500 mt-1 block">92/100</span>
         </div>
      </div>

      <TitleOptimisationHeatmap />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Keyword Gap Analysis" subtitle="High volume keywords missing from titles">
            <div className="space-y-4">
                {[
                    { sku: 'SKU-101', missing: ['Sugar Free', 'Electrolytes', 'Gym'], volume: 'High' },
                    { sku: 'SKU-205', missing: ['Keto Friendly', 'Vegan'], volume: 'Medium' },
                    { sku: 'SKU-300', missing: ['Organic', 'Detox'], volume: 'Medium' },
                ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-200">
                        <div>
                            <p className="font-bold text-sm text-gray-900">{item.sku}</p>
                            <div className="flex flex-wrap gap-1 mt-1">
                                {item.missing.map((kw, i) => (
                                    <span key={i} className="px-2 py-0.5 bg-red-100 text-red-700 text-[10px] font-bold rounded border border-red-200">
                                        {kw}
                                    </span>
                                ))}
                            </div>
                        </div>
                        <div className="text-right">
                            <span className="text-xs font-bold text-black block">Search Vol</span>
                            <span className={`text-xs font-bold ${item.volume === 'High' ? 'text-red-600' : 'text-amber-600'}`}>
                                {item.volume}
                            </span>
                        </div>
                    </div>
                ))}
            </div>
        </Card>

        <Card title="Content Gap Leaderboard" subtitle="Revenue at risk due to poor content">
             <div className="space-y-3">
                 {[
                     { sku: 'SKU-205', gap: 'Missing Video', risk: '₹12L', urgency: 'high' },
                     { sku: 'SKU-300', gap: 'Short Description', risk: '₹8L', urgency: 'medium' },
                     { sku: 'SKU-101', gap: 'Low Res Hero', risk: '₹5L', urgency: 'medium' },
                 ].map((item, idx) => (
                     <div key={idx} className="flex items-center justify-between p-3 bg-white rounded border-l-4 border-l-red-500 shadow-sm border border-gray-100">
                         <div>
                             <p className="font-bold text-sm text-gray-900">{item.sku}</p>
                             <p className="text-xs text-black">{item.gap}</p>
                         </div>
                         <div className="text-right">
                             <p className="font-bold text-red-600">{item.risk}</p>
                             <p className="text-[10px] text-black uppercase">Revenue Risk</p>
                         </div>
                     </div>
                 ))}
             </div>
        </Card>
      </div>
    </div>
  );
};

export default ContentAuditView;
