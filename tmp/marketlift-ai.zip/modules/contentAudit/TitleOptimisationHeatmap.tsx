
import React, { useState } from 'react';
import Card from '../../components/shared/Card';
import { mockContentHealthScores, mockProductTitles } from '../../data/mockData';
import { suggestContentRewrite, ContentSuggestion } from '../../services/geminiService';
import { SparklesIcon, LoadingSpinner } from '../../components/icons/ModuleIcons';

const TitleOptimisationHeatmap: React.FC = () => {
  const [suggestions, setSuggestions] = useState<Record<string, ContentSuggestion>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});

  const handleRewrite = async (sku: string, retailer: string) => {
    const key = `${sku}-${retailer}`;
    setLoading((prev) => ({ ...prev, [key]: true }));
    const currentTitle = mockProductTitles[sku];
    // Assuming category is Energy Drinks based on context
    const suggestion = await suggestContentRewrite(currentTitle, "Energy Drinks");
    setSuggestions((prev) => ({ ...prev, [key]: suggestion }));
    setLoading((prev) => ({ ...prev, [key]: false }));
  };
  
  const getScoreColor = (score: number) => {
    if (score < 50) return 'bg-red-100 text-red-700';
    if (score < 80) return 'bg-amber-100 text-amber-700';
    return 'bg-green-100 text-green-700';
  };

  return (
    <Card
      title="Content Optimisation Heatmap"
      subtitle="Which product titles and descriptions need immediate improvement?"
    >
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="border-b border-gray-200 bg-gray-50">
            <tr>
              <th className="p-3 text-xs font-bold text-gray-500 uppercase tracking-wider">SKU</th>
              <th className="p-3 text-xs font-bold text-gray-500 uppercase tracking-wider">Retailer</th>
              <th className="p-3 text-xs font-bold text-gray-500 uppercase tracking-wider">Current Title</th>
              <th className="p-3 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Title Score</th>
              <th className="p-3 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Keyword Score</th>
              <th className="p-3 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Action</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {mockContentHealthScores.map(({ sku, retailer, titleScore }) => {
              const key = `${sku}-${retailer}`;
              const keywordScore = Math.max(30, titleScore - 15); // Mock derived score
              return (
                <tr key={key} className="hover:bg-gray-50 transition-colors">
                  <td className="p-3 font-mono text-sm text-gray-600">{sku}</td>
                  <td className="p-3 text-sm text-gray-900 font-medium">{retailer}</td>
                  <td className="p-3 text-gray-600 text-sm max-w-xs truncate" title={mockProductTitles[sku]}>{mockProductTitles[sku]}</td>
                  <td className="p-3 text-center">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${getScoreColor(titleScore)}`}>
                      {titleScore}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${getScoreColor(keywordScore)}`}>
                      {keywordScore}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <button
                        onClick={() => handleRewrite(sku, retailer)}
                        disabled={loading[key]}
                        className="flex items-center justify-center mx-auto space-x-2 px-3 py-1.5 rounded-md bg-brand-accent hover:bg-blue-700 transition-colors text-white text-xs font-semibold disabled:bg-gray-300 disabled:cursor-not-allowed shadow-sm"
                    >
                      {loading[key] ? (
                        <LoadingSpinner className="h-3 w-3" />
                      ) : (
                        <SparklesIcon className="h-3 w-3" />
                      )}
                      <span>{loading[key] ? 'Thinking...' : 'Rewrite'}</span>
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {Object.keys(suggestions).length > 0 && (
             <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <h4 className="font-bold mb-4 text-gray-900 flex items-center">
                    <SparklesIcon className="w-5 h-5 text-brand-accent mr-2" />
                    AI Content Suggestions
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(suggestions).map(([key, suggestion]) => (
                    <div key={key} className="bg-white p-4 rounded border border-gray-200 shadow-sm">
                        <div className="text-xs text-gray-500 mb-2 uppercase font-bold tracking-wider">{key}</div>
                        <div className="mb-3">
                            <span className="text-xs text-brand-accent font-bold block mb-1">Suggested Title:</span>
                            <p className="text-sm text-gray-900 font-medium">{(suggestion as ContentSuggestion).title}</p>
                        </div>
                        <div>
                            <span className="text-xs text-brand-accent font-bold block mb-1">Suggested Description:</span>
                            <p className="text-sm text-gray-600 italic">"{(suggestion as ContentSuggestion).description}"</p>
                        </div>
                    </div>
                ))}
                </div>
            </div>
        )}
      </div>
    </Card>
  );
};

export default TitleOptimisationHeatmap;
