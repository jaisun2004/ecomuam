
import React from 'react';
import Card from '../../components/shared/Card';
import { shareOfShelfData } from '../../data/mockData';

const ShareOfShelfView: React.FC = () => {
  return (
    <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Organic Rank Tracker */}
            <Card title="Organic Rank Tracker" subtitle="Am I winning the organic shelf?">
                <div className="space-y-4 mt-2">
                    {shareOfShelfData.organicRanks.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-200 shadow-sm">
                            <div className="flex items-center space-x-3">
                                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                                <span className="text-sm font-bold text-gray-900">{item.brand}</span>
                            </div>
                            <div className="flex items-center space-x-4">
                                <div className="text-right">
                                    <span className="text-xs text-gray-500 block">Rank</span>
                                    <span className="text-xl font-bold text-gray-900">#{item.rank}</span>
                                </div>
                                <div className={`text-xs font-bold px-2 py-1 rounded ${item.change < 0 ? 'bg-red-100 text-red-600' : item.change > 0 ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                                    {item.change > 0 ? '▲' : item.change < 0 ? '▼' : '−'} {Math.abs(item.change)}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </Card>

            {/* Sponsored Rank Tracker */}
            <Card title="Sponsored Rank Tracker" subtitle="Paid visibility vs Competitors">
                <div className="space-y-4 mt-2">
                    {shareOfShelfData.sponsoredRanks.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-200 shadow-sm">
                            <div className="flex items-center space-x-3">
                                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                                <span className="text-sm font-bold text-gray-900">{item.brand}</span>
                            </div>
                            <div className="flex items-center space-x-4">
                                <div className="text-right">
                                    <span className="text-xs text-gray-500 block">Ad Rank</span>
                                    <span className="text-xl font-bold text-gray-900">#{item.rank}</span>
                                </div>
                                <div className={`text-xs font-bold px-2 py-1 rounded ${item.change < 0 ? 'bg-red-100 text-red-600' : item.change > 0 ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                                    {item.change > 0 ? '▲' : item.change < 0 ? '▼' : '−'} {Math.abs(item.change)}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Share Breakdown */}
            <div className="lg:col-span-1">
                <Card title="Share of Shelf Breakdown" subtitle="Organic vs Sponsored Visibility">
                    <div className="flex flex-col items-center justify-center h-full py-6">
                        <div className="flex items-end space-x-8 h-48 w-full px-4 justify-center">
                            {shareOfShelfData.shareBreakdown.map((item, idx) => (
                                <div key={idx} className="flex-1 flex flex-col items-center group max-w-[80px]">
                                    <div className="relative w-full bg-gray-100 rounded-t-lg overflow-hidden border border-gray-200 border-b-0" style={{ height: '100%' }}>
                                        <div 
                                            className="absolute bottom-0 left-0 right-0 transition-all duration-500"
                                            style={{ height: `${item.value}%`, backgroundColor: item.color }}
                                        ></div>
                                    </div>
                                    <span className="mt-3 text-xl font-bold text-gray-900">{item.value}%</span>
                                    <span className="text-[10px] text-gray-500 uppercase tracking-wider font-bold">{item.type}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </Card>
            </div>

            {/* Rank Cannibalisation Detector (Existing) */}
            <div className="lg:col-span-2">
                <Card title="Rank Cannibalisation Detector" subtitle="Am I paying for clicks I own organically?">
                    <div className="h-64 bg-gray-50 rounded flex items-center justify-center relative border border-gray-200">
                        <div className="w-full h-full p-4 relative">
                            <div className="absolute left-0 top-0 bottom-0 w-8 flex flex-col justify-between text-xs text-gray-400 py-4">
                                <span>#1</span>
                                <span>#10</span>
                                <span>#20</span>
                            </div>
                            <svg className="absolute left-10 right-0 top-4 bottom-4 w-[95%] h-[90%] overflow-visible">
                                <path d="M0,80 Q100,20 200,40 T400,10" fill="none" stroke="#3b82f6" strokeWidth="3" />
                                <text x="410" y="10" fill="#3b82f6" fontSize="12" fontWeight="bold">"Energy Drink" (Org)</text>
                                
                                <path d="M0,150 Q100,140 200,100 T400,120" fill="none" stroke="#a855f7" strokeWidth="2" strokeDasharray="5,5" />
                                <text x="410" y="120" fill="#a855f7" fontSize="12" fontWeight="bold">"Hydration" (Paid)</text>
                                
                                {/* Cannibalisation Highlight */}
                                <circle cx="200" cy="40" r="15" fill="none" stroke="red" strokeWidth="2" />
                                <text x="220" y="45" fill="red" fontSize="10" fontWeight="bold">High Overlap</text>
                            </svg>
                        </div>
                    </div>
                    <div className="mt-4 flex justify-end">
                        <button className="text-xs bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-3 py-1.5 rounded transition-colors font-medium shadow-sm">
                            Reduce Bids on Overlapping Terms
                        </button>
                    </div>
                </Card>
            </div>
        </div>
    </div>
  );
};

export default ShareOfShelfView;
