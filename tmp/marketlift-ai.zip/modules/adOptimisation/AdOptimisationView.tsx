
import React, { useState } from 'react';
import Card from '../../components/shared/Card';
import { adReadinessData, roasHeatmapData, keywordGapData, cannibalisationData } from '../../data/mockData';
import { HeatmapGrid, ScatterPlot } from '../../components/shared/Visuals';
import { generatePoachingCampaign, PoachingCampaign } from '../../services/geminiService';
import { SparklesIcon, LoadingSpinner } from '../../components/icons/ModuleIcons';

const AdOptimisationView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'planning' | 'creation' | 'reporting' | 'optimisation'>('reporting');
  const [loading, setLoading] = useState<string | null>(null);
  const [campaignBrief, setCampaignBrief] = useState<PoachingCampaign | null>(null);
  const [showDetailedReporting, setShowDetailedReporting] = useState(false);

  const handleTriggerPoaching = async (platform: string, cluster: string, competitor: string) => {
    setLoading(`${platform}-${cluster}`);
    const brief = await generatePoachingCampaign(platform, cluster, competitor);
    setCampaignBrief(brief);
    setLoading(null);
  };

  const [selectedStrategy, setSelectedStrategy] = useState('Brand Defense');
  const [strategyBidMultipliers, setStrategyBidMultipliers] = useState<Record<string, Record<string, number>>>({
      'Brand Defense': {},
      'Conquesting': {},
      'Awareness': {}
  });

  const currentMultipliers = strategyBidMultipliers[selectedStrategy] || {};

  const toggleBid = (day: string, hour: number) => {
    const key = `${day}-${hour}`;
    const current = currentMultipliers[key] || 1.0;
    let next = 1.0;
    if (current === 1.0) next = 1.2; // High Bid
    else if (current === 1.2) next = 0.5; // Low Bid
    else next = 1.0; // Standard
    
    setStrategyBidMultipliers({
        ...strategyBidMultipliers,
        [selectedStrategy]: {
            ...currentMultipliers,
            [key]: next
        }
    });
  };

  const getBidColor = (multiplier: number) => {
      if (multiplier > 1.0) return 'bg-green-500 hover:bg-green-600';
      if (multiplier < 1.0) return 'bg-red-200 hover:bg-red-300';
      return 'bg-blue-100 hover:bg-blue-200';
  };

  const tabs = [
    { id: 'planning', label: 'Planning' },
    { id: 'creation', label: 'Campaign Creation' },
    { id: 'reporting', label: 'Reporting' },
    { id: 'optimisation', label: 'Optimisation (Rules & AI)' },
  ];

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit border border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
              activeTab === tab.id
                ? 'bg-white text-brand-accent shadow-sm'
                : 'text-gray-500 hover:text-gray-900 hover:bg-gray-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content based on Tab */}
      {activeTab === 'planning' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
             <div className="lg:col-span-2">
                <Card title="Budget Planner" subtitle="Forecasted ROAS based on spend allocation">
                    <div className="space-y-6">
                        <div className="p-6 bg-gray-50 rounded-lg border border-gray-200">
                            <div className="flex justify-between mb-4 items-center">
                                <span className="font-bold text-gray-700 text-sm uppercase tracking-wide">Total Monthly Budget</span>
                                <div className="flex items-center bg-white px-3 py-1 rounded border border-gray-300 shadow-sm">
                                    <span className="text-gray-500 mr-1">₹</span>
                                    <input 
                                        type="number" 
                                        defaultValue={500000} 
                                        className="font-bold text-gray-900 w-24 text-right outline-none"
                                    />
                                </div>
                            </div>
                            <input type="range" className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-accent mb-2" />
                            <div className="flex justify-between text-xs text-gray-400 font-medium">
                                <span>Min: ₹1L</span>
                                <span>Max: ₹10L</span>
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="p-4 bg-white border border-gray-200 rounded-lg shadow-sm flex flex-col items-center justify-center relative overflow-hidden group">
                                <div className="absolute top-0 left-0 w-1 h-full bg-blue-500"></div>
                                <p className="text-xs text-gray-500 font-bold uppercase mb-1">Forecasted Revenue</p>
                                <p className="text-2xl font-bold text-gray-900">₹18.5L</p>
                                <p className="text-[10px] text-green-600 font-bold mt-1 bg-green-50 px-2 py-0.5 rounded-full">+12% vs last month</p>
                            </div>
                            <div className="p-4 bg-white border border-gray-200 rounded-lg shadow-sm flex flex-col items-center justify-center relative overflow-hidden group">
                                <div className="absolute top-0 left-0 w-1 h-full bg-green-500"></div>
                                <p className="text-xs text-gray-500 font-bold uppercase mb-1">Forecasted ROAS</p>
                                <p className="text-2xl font-bold text-gray-900">3.7x</p>
                                <p className="text-[10px] text-green-600 font-bold mt-1 bg-green-50 px-2 py-0.5 rounded-full">High Efficiency</p>
                            </div>
                            <div className="p-4 bg-white border border-gray-200 rounded-lg shadow-sm flex flex-col items-center justify-center relative overflow-hidden group">
                                <div className="absolute top-0 left-0 w-1 h-full bg-purple-500"></div>
                                <p className="text-xs text-gray-500 font-bold uppercase mb-1">Est. Clicks</p>
                                <p className="text-2xl font-bold text-gray-900">45.2K</p>
                                <p className="text-[10px] text-gray-400 font-bold mt-1">Based on avg CPC ₹11</p>
                            </div>
                        </div>
                    </div>
                </Card>
             </div>
             
             <div className="lg:col-span-1">
                <Card title="Channel Allocation" subtitle="Recommended split">
                    <div className="space-y-4 py-2">
                        {[
                            { name: 'Amazon Ads', pct: 60, color: '#FF9900' }, 
                            { name: 'Flipkart Ads', pct: 25, color: '#2874F0' }, 
                            { name: 'Blinkit', pct: 10, color: '#F8CB46' }, 
                            { name: 'Zepto', pct: 5, color: '#592694' }
                        ].map((channel, i) => (
                            <div key={i} className="group">
                                <div className="flex justify-between text-xs mb-1">
                                    <span className="font-bold text-gray-700">{channel.name}</span>
                                    <span className="font-bold text-gray-900">{channel.pct}%</span>
                                </div>
                                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                                    <div 
                                        className="h-full rounded-full transition-all duration-500 group-hover:opacity-80" 
                                        style={{ width: `${channel.pct}%`, backgroundColor: channel.color }}
                                    ></div>
                                </div>
                            </div>
                        ))}
                        <div className="pt-4 mt-4 border-t border-gray-100">
                            <button className="w-full py-2 text-xs font-bold text-brand-accent border border-brand-accent rounded hover:bg-brand-accent hover:text-white transition-colors">
                                Recalculate Split
                            </button>
                        </div>
                    </div>
                </Card>
             </div>
        </div>
      )}

      {activeTab === 'creation' && (
        <div className="space-y-6">
            <div className="flex justify-end">
                <button className="px-4 py-2 bg-brand-accent text-white rounded-lg font-bold shadow-sm hover:bg-blue-700 transition-colors flex items-center">
                    <span className="mr-2">+</span> Create New Campaign
                </button>
            </div>
            <Card title="Active Campaigns" subtitle="Manage your running ads">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th className="p-3 text-xs font-bold text-gray-500 uppercase">Campaign Name</th>
                            <th className="p-3 text-xs font-bold text-gray-500 uppercase">Status</th>
                            <th className="p-3 text-xs font-bold text-gray-500 uppercase">Budget</th>
                            <th className="p-3 text-xs font-bold text-gray-500 uppercase">ROAS</th>
                            <th className="p-3 text-xs font-bold text-gray-500 uppercase">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {[
                            { name: 'Summer Sale - Energy Drinks', status: 'Active', budget: '₹50,000', roas: '4.2x' },
                            { name: 'Competitor Conquesting - RedBull', status: 'Active', budget: '₹30,000', roas: '2.8x' },
                            { name: 'Brand Defense', status: 'Paused', budget: '₹20,000', roas: '5.1x' },
                        ].map((c, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="p-3 text-sm font-medium text-gray-900">{c.name}</td>
                                <td className="p-3">
                                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${c.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                        {c.status}
                                    </span>
                                </td>
                                <td className="p-3 text-sm text-gray-600">{c.budget}</td>
                                <td className="p-3 text-sm font-bold text-gray-900">{c.roas}</td>
                                <td className="p-3">
                                    <button className="text-brand-accent hover:text-blue-800 text-xs font-bold">Edit</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </Card>
        </div>
      )}

      {activeTab === 'reporting' && (
        <div className="space-y-6">
            {!showDetailedReporting ? (
                <>
                    <div className="flex justify-end">
                        <button 
                            onClick={() => setShowDetailedReporting(true)}
                            className="px-4 py-2 bg-brand-accent text-white text-sm font-bold rounded shadow-sm hover:bg-blue-700 transition-colors"
                        >
                            View Detailed Reporting
                        </button>
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <Card title="ROAS Heatmap" subtitle="Where is my ad spend most efficient?">
                            <HeatmapGrid data={roasHeatmapData} />
                            <button className="mt-4 text-xs text-brand-accent hover:text-blue-800 underline font-medium">
                                Auto-Reallocate Budget to High ROAS Cells
                            </button>
                        </Card>
        
                        <Card title="Keyword Opportunity Gap" subtitle="Which keywords should I be bidding on?">
                            <div className="space-y-4 mt-2">
                                {keywordGapData.map((d, i) => (
                                    <div key={i}>
                                        <div className="flex justify-between text-xs mb-1">
                                            <span className="text-black font-medium">"{d.keyword}"</span>
                                            <span className="text-black">Vol: {d.volume}</span>
                                        </div>
                                        <div className="flex h-3 rounded-full overflow-hidden bg-gray-200">
                                            <div className="bg-brand-accent" style={{ width: `${d.myShare}%` }} title={`Me: ${d.myShare}%`}></div>
                                            <div className="bg-red-400" style={{ width: `${d.compShare}%` }} title={`Comp: ${d.compShare}%`}></div>
                                        </div>
                                        <div className="flex justify-between text-[10px] text-black mt-1">
                                            <span>My Share: {d.myShare}%</span>
                                            <button className="text-brand-accent hover:text-blue-800 uppercase font-bold tracking-wider">Launch Campaign</button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </Card>
                    </div>
        
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <Card title="Sponsored vs. Organic Cannibalisation" subtitle="Am I paying for clicks I'd get for free?">
                                <ScatterPlot 
                                    data={cannibalisationData.map(d => ({
                                        x: d.organicRank,
                                        y: d.cpc,
                                        label: d.keyword,
                                        type: d.organicRank <= 3 ? 'warning' : 'safe'
                                    }))}
                                    xLabel="Organic Rank (Lower is Better)"
                                    yLabel="CPC (₹)"
                                />
                                <div className="mt-2 text-center">
                                    <p className="text-xs text-black"><span className="text-red-500 font-bold">● Warning</span>: High Organic Rank + High Ad Spend. Consider reducing bids.</p>
                                </div>
                        </Card>
                        
                        <Card title="Bid Landscape" subtitle="Impression share vs. Bid Level">
                            <div className="h-64 flex items-center justify-center bg-gray-50 rounded border border-gray-200 border-dashed">
                                <p className="text-black text-sm">Interactive Bid Simulator Visualization</p>
                            </div>
                        </Card>
                    </div>
                </>
            ) : (
                <div className="space-y-4 animate-fadeIn">
                    <div className="flex justify-between items-center">
                        <h3 className="text-lg font-bold text-black">Detailed Performance Report</h3>
                        <button 
                            onClick={() => setShowDetailedReporting(false)}
                            className="text-sm text-brand-accent hover:underline font-medium"
                        >
                            ← Back to Dashboard
                        </button>
                    </div>
                    <Card title="Granular Performance Data" subtitle="Platform > Campaign > Keyword > SKU > City">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead className="bg-gray-100">
                                    <tr>
                                        <th className="p-3 text-xs font-bold text-black uppercase border-b border-gray-300">Platform</th>
                                        <th className="p-3 text-xs font-bold text-black uppercase border-b border-gray-300">Campaign</th>
                                        <th className="p-3 text-xs font-bold text-black uppercase border-b border-gray-300">Keyword</th>
                                        <th className="p-3 text-xs font-bold text-black uppercase border-b border-gray-300">SKU</th>
                                        <th className="p-3 text-xs font-bold text-black uppercase border-b border-gray-300">City</th>
                                        <th className="p-3 text-xs font-bold text-black uppercase border-b border-gray-300 text-right">Spend</th>
                                        <th className="p-3 text-xs font-bold text-black uppercase border-b border-gray-300 text-right">ROAS</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200">
                                    {[
                                        { platform: 'Amazon', campaign: 'Summer Sale', keyword: 'energy drink', sku: 'SKU-101', city: 'Mumbai', spend: '₹5,000', roas: 4.2 },
                                        { platform: 'Amazon', campaign: 'Summer Sale', keyword: 'energy drink', sku: 'SKU-101', city: 'Delhi', spend: '₹3,200', roas: 3.8 },
                                        { platform: 'Flipkart', campaign: 'Brand Defense', keyword: 'my brand', sku: 'SKU-205', city: 'Bangalore', spend: '₹1,500', roas: 5.5 },
                                        { platform: 'Blinkit', campaign: 'Impulse', keyword: 'refreshment', sku: 'SKU-300', city: 'Mumbai', spend: '₹800', roas: 2.1 },
                                        { platform: 'Amazon', campaign: 'Conquesting', keyword: 'redbull', sku: 'SKU-101', city: 'Pune', spend: '₹2,100', roas: 1.8 },
                                    ].map((row, i) => (
                                        <tr key={i} className="hover:bg-gray-50">
                                            <td className="p-3 text-sm text-black">{row.platform}</td>
                                            <td className="p-3 text-sm text-black">{row.campaign}</td>
                                            <td className="p-3 text-sm text-black">{row.keyword}</td>
                                            <td className="p-3 text-sm text-black">{row.sku}</td>
                                            <td className="p-3 text-sm text-black">{row.city}</td>
                                            <td className="p-3 text-sm text-black font-mono text-right">{row.spend}</td>
                                            <td className={`p-3 text-sm font-bold text-right ${row.roas >= 4 ? 'text-green-600' : row.roas < 2 ? 'text-red-600' : 'text-amber-600'}`}>{row.roas}x</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Card>
                </div>
            )}
        </div>
      )}

      {activeTab === 'optimisation' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card title="Rule Engine" subtitle="Automated optimization rules">
                  <div className="space-y-3">
                      {[
                          { name: 'Low ROAS Pause', condition: 'If ROAS < 1.5 for 3 days', action: 'Pause Keyword', status: 'Active' },
                          { name: 'High Performer Boost', condition: 'If ROAS > 4.0', action: 'Increase Bid 10%', status: 'Active' },
                          { name: 'Inventory Protection', condition: 'If Stock < 5 days', action: 'Pause Campaign', status: 'Inactive' },
                      ].map((rule, i) => (
                          <div key={i} className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded shadow-sm">
                              <div>
                                  <p className="font-bold text-sm text-gray-900">{rule.name}</p>
                                  <p className="text-xs text-gray-500">{rule.condition} → <span className="text-brand-accent">{rule.action}</span></p>
                              </div>
                              <div className={`w-3 h-3 rounded-full ${rule.status === 'Active' ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                          </div>
                      ))}
                  </div>
                  <button className="mt-4 w-full py-2 border border-dashed border-gray-300 rounded text-gray-500 text-sm hover:bg-gray-50 hover:text-gray-700 transition-colors">
                      + Add New Rule
                  </button>
              </Card>

              <Card title="Day Parting Schedule" subtitle="Optimize bids by time of day">
                  <div className="mb-4 flex items-center space-x-2">
                      <span className="text-sm font-bold text-black">Campaign Strategy:</span>
                      <select 
                          value={selectedStrategy}
                          onChange={(e) => setSelectedStrategy(e.target.value)}
                          className="border border-gray-300 rounded px-2 py-1 text-sm text-black focus:outline-none focus:border-brand-accent"
                      >
                          <option value="Brand Defense">Brand Defense</option>
                          <option value="Conquesting">Conquesting</option>
                          <option value="Awareness">Awareness</option>
                      </select>
                  </div>
                  <div className="overflow-x-auto">
                      <div className="min-w-[600px]">
                          <div className="grid grid-cols-[auto_repeat(24,1fr)] gap-0.5 mb-1">
                              <div className="w-12"></div>
                              {Array.from({ length: 24 }).map((_, i) => (
                                  <div key={i} className="text-[10px] text-black text-center font-mono">{i}</div>
                              ))}
                          </div>
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
                              <div key={day} className="grid grid-cols-[auto_repeat(24,1fr)] gap-0.5 mb-1 items-center">
                                  <div className="text-[10px] font-bold text-black w-12">{day}</div>
                                  {Array.from({ length: 24 }).map((_, hour) => {
                                      const key = `${day}-${hour}`;
                                      const multiplier = currentMultipliers[key] || 1.0;
                                      return (
                                          <div 
                                              key={hour} 
                                              onClick={() => toggleBid(day, hour)}
                                              className={`h-6 rounded-[2px] transition-all cursor-pointer flex items-center justify-center text-[8px] font-bold text-black ${getBidColor(multiplier)}`}
                                              title={`${day} ${hour}:00 - Bid Multiplier: ${multiplier}x`}
                                          >
                                              {multiplier !== 1.0 && `${multiplier}x`}
                                          </div>
                                      );
                                  })}
                              </div>
                          ))}
                      </div>
                  </div>
                  <div className="flex items-center space-x-6 mt-4 text-xs text-black">
                      <div className="flex items-center"><div className="w-3 h-3 bg-blue-100 border border-blue-200 rounded-sm mr-2"></div> Standard (1.0x)</div>
                      <div className="flex items-center"><div className="w-3 h-3 bg-green-500 border border-green-600 rounded-sm mr-2"></div> High Bid (1.2x)</div>
                      <div className="flex items-center"><div className="w-3 h-3 bg-red-200 border border-red-300 rounded-sm mr-2"></div> Low Bid (0.5x)</div>
                  </div>
                  <p className="text-xs text-black mt-2 italic">
                      Click on cells to toggle bid multipliers: Standard → High → Low → Standard.
                  </p>
              </Card>
          </div>
      )}
    </div>
  );
};

export default AdOptimisationView;
