
import React from 'react';
import Card from '../../components/shared/Card';
import { SimpleBarChart } from '../../components/shared/Visuals';

const CategoryRecommendationView: React.FC = () => {
  // Mock Data for NPD
  const flavorOpportunities = [
    { label: 'Mango Chilli', demand: 85, competition: 20, potential: 'High' },
    { label: 'Blueberry Mint', demand: 78, competition: 35, potential: 'High' },
    { label: 'Spicy Guava', demand: 65, competition: 60, potential: 'Medium' },
    { label: 'Classic Lemon', demand: 95, competition: 90, potential: 'Low' },
  ];

  const packSizeOpportunities = [
    { label: 'Multipack (6x250ml)', growth: 12.5, share: 5 },
    { label: 'Party Pack (2L)', growth: 8.2, share: 15 },
    { label: 'On-the-go (200ml)', growth: -2.0, share: 40 },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Hero Card: Top Recommendation */}
            <div className="lg:col-span-2">
                <Card title="Top NPD Opportunity: 'Mango Chilli' Variant" subtitle="High Demand, Low Competition Space">
                    <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
                        <div className="w-full md:w-1/3 bg-gray-50 p-4 rounded-lg border border-gray-200 text-center shadow-sm">
                            <div className="text-4xl font-bold text-green-500 mb-1">85/100</div>
                            <div className="text-xs text-black uppercase tracking-wider font-bold">Opportunity Score</div>
                            <div className="mt-4 space-y-2 text-left text-sm">
                                <div className="flex justify-between">
                                    <span className="text-black">Search Volume</span>
                                    <span className="text-gray-900 font-bold">High</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-black">Competitor Density</span>
                                    <span className="text-green-600 font-bold">Low</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-black">Avg. Category Price</span>
                                    <span className="text-gray-900 font-bold">₹110</span>
                                </div>
                            </div>
                        </div>
                        <div className="flex-1 space-y-4">
                            <p className="text-sm text-black leading-relaxed">
                                Analysis of search queries and competitor listings suggests a gap in the market for <span className="text-gray-900 font-bold">Spicy/Tangy Fruit Blends</span>. 
                                "Mango Chilli" has seen a <span className="text-green-600 font-bold">+45%</span> increase in search volume over the last quarter with only 2 niche competitors.
                            </p>
                            <div className="p-3 bg-blue-50 border border-blue-100 rounded">
                                <h5 className="text-xs font-bold text-blue-700 uppercase mb-1">Recommended Action</h5>
                                <p className="text-xs text-blue-900">Launch "Mango Chilli" 250ml Can at ₹50 price point to capture early adopters.</p>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>

            {/* Quick Stats */}
            <div className="space-y-6">
                <Card title="Flavor Gap Analysis" subtitle="Demand vs Competition">
                    <div className="space-y-3">
                        {flavorOpportunities.map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between">
                                <span className="text-sm text-black w-1/3 font-medium">{item.label}</span>
                                <div className="flex-1 mx-2 h-2 bg-gray-200 rounded-full overflow-hidden flex">
                                    <div className="bg-green-500 h-full" style={{ width: `${item.demand}%` }} title="Demand"></div>
                                    <div className="bg-red-500 h-full" style={{ width: `${item.competition}%` }} title="Competition"></div>
                                </div>
                                <span className={`text-xs font-bold w-12 text-right ${item.potential === 'High' ? 'text-green-600' : item.potential === 'Medium' ? 'text-amber-600' : 'text-gray-500'}`}>
                                    {item.potential}
                                </span>
                            </div>
                        ))}
                        <div className="flex justify-center space-x-4 mt-2 text-[10px] text-black">
                            <div className="flex items-center"><div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div> Demand</div>
                            <div className="flex items-center"><div className="w-2 h-2 bg-red-500 rounded-full mr-1"></div> Competition</div>
                        </div>
                    </div>
                </Card>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="Pack Size Trends" subtitle="Which formats are growing?">
                <div className="mt-4">
                    <SimpleBarChart 
                        data={packSizeOpportunities.map(d => ({ 
                            label: d.label, 
                            value: d.growth, 
                            color: d.growth > 0 ? '#10b981' : '#ef4444' 
                        }))} 
                        height={180}
                        showValue
                    />
                    <p className="text-xs text-center text-black mt-2">YoY Growth Rate (%)</p>
                </div>
            </Card>

            <Card title="Variant Rationalisation" subtitle="Candidates for delisting">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="border-b border-gray-200 text-xs text-black uppercase bg-gray-50">
                                <th className="p-2 font-bold">Variant</th>
                                <th className="p-2 text-center font-bold">Sales Vol</th>
                                <th className="p-2 text-center font-bold">Margin</th>
                                <th className="p-2 text-center font-bold">Recommendation</th>
                            </tr>
                        </thead>
                        <tbody className="text-sm divide-y divide-gray-100">
                            <tr className="hover:bg-gray-50">
                                <td className="p-2 text-gray-900 font-medium">Cola 1.5L</td>
                                <td className="p-2 text-center text-red-600 font-bold">Low</td>
                                <td className="p-2 text-center text-amber-600">12%</td>
                                <td className="p-2 text-center"><span className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-bold">Delist</span></td>
                            </tr>
                            <tr className="hover:bg-gray-50">
                                <td className="p-2 text-gray-900 font-medium">Lemon 200ml</td>
                                <td className="p-2 text-center text-amber-600 font-bold">Med</td>
                                <td className="p-2 text-center text-red-600">5%</td>
                                <td className="p-2 text-center"><span className="px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs font-bold">Reprice</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    </div>
  );
};

export default CategoryRecommendationView;
