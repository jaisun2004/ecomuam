
import React, { useEffect, useState, useCallback } from 'react';
import { mockOpportunities } from '../../data/mockData';
import { Opportunity, OpportunityClassification } from '../../types';
import { classifyOpportunities } from '../../services/geminiService';
import { CloseIcon, LoadingSpinner } from '../../components/icons/ModuleIcons';

interface OpportunityMatrixProps {
  onClose: () => void;
}

const OpportunityMatrix: React.FC<OpportunityMatrixProps> = ({ onClose }) => {
  const [classifications, setClassifications] = useState<OpportunityClassification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchClassifications = useCallback(async () => {
    setIsLoading(true);
    const result = await classifyOpportunities(mockOpportunities);
    setClassifications(result);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchClassifications();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getOpportunityById = (id: string): Opportunity | undefined => {
    return mockOpportunities.find(op => op.id === id);
  }

  const renderQuadrant = (impact: 'High' | 'Low', ease: 'Easy' | 'Hard') => {
    const quadrantOpportunities = classifications.filter(
      c => c.revenueImpact === impact && c.easeOfFix === ease
    ).map(c => getOpportunityById(c.id)).filter(Boolean) as Opportunity[];

    return (
      <div className="bg-brand-medium rounded-lg p-4 h-full overflow-y-auto">
        {quadrantOpportunities.length > 0 ? (
          <ul className="space-y-2">
            {quadrantOpportunities.map(op => (
              <li key={op.id} className="text-sm p-2 bg-brand-light rounded hover:bg-brand-accent/50 cursor-pointer transition-colors">
                <p className="font-semibold text-gray-200">{op.module}</p>
                <p className="text-gray-400">{op.description}</p>
              </li>
            ))}
          </ul>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-500 text-sm">No opportunities here.</p>
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-brand-dark w-full max-w-4xl h-[90vh] max-h-[800px] rounded-xl shadow-2xl flex flex-col relative">
        <div className="p-6 border-b border-brand-light flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white">Opportunity Prioritization Matrix</h2>
            <p className="text-gray-400">AI-powered 2x2 to focus your efforts on what matters most.</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-brand-medium transition-colors">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        {isLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <LoadingSpinner className="w-12 h-12 text-brand-accent" />
            <p className="mt-4 text-lg font-semibold text-white">Gemini is analyzing opportunities...</p>
            <p className="text-gray-400">This may take a moment.</p>
          </div>
        ) : (
          <div className="flex-1 p-6 grid grid-cols-[auto,1fr,1fr] grid-rows-[auto,1fr,1fr] gap-4">
            {/* Y-Axis Labels */}
            <div className="flex items-center justify-center -rotate-90 row-start-2">
                <span className="text-sm font-bold tracking-wider text-gray-300">HIGH IMPACT</span>
            </div>
            <div className="flex items-center justify-center -rotate-90 row-start-3">
                <span className="text-sm font-bold tracking-wider text-gray-300">LOW IMPACT</span>
            </div>
            
            {/* X-Axis Labels */}
            <div className="text-center col-start-2">
                <span className="text-sm font-bold tracking-wider text-gray-300">EASY FIX</span>
            </div>
            <div className="text-center col-start-3">
                <span className="text-sm font-bold tracking-wider text-gray-300">HARD FIX</span>
            </div>

            {/* Quadrants */}
            <div className="col-start-2 row-start-2 border-2 border-green-500 rounded-lg p-1 bg-green-500/10">
                {renderQuadrant('High', 'Easy')}
            </div>
            <div className="col-start-3 row-start-2 border-2 border-amber-500 rounded-lg p-1 bg-amber-500/10">
                {renderQuadrant('High', 'Hard')}
            </div>
            <div className="col-start-2 row-start-3 border-2 border-blue-500 rounded-lg p-1 bg-blue-500/10">
                {renderQuadrant('Low', 'Easy')}
            </div>
            <div className="col-start-3 row-start-3">
                {renderQuadrant('Low', 'Hard')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default OpportunityMatrix;
