
import { GoogleGenAI, Type } from "@google/genai";
import { Opportunity } from '../types';

if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this context, we assume it's set.
  console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export interface ContentSuggestion {
  title: string;
  description: string;
}

export const suggestContentRewrite = async (currentTitle: string, category: string = "General"): Promise<ContentSuggestion> => {
  try {
    const prompt = `You are an expert ecommerce copywriter for the "${category}" category. 
    Your task is to rewrite a product title and provide a short, compelling description to maximize click-through rate and conversion.
    
    Follow these best practices:
    1. Title: Include the brand name, key features, and high-volume keywords. Keep it concise (50-80 chars).
    2. Description: Write a 1-sentence hook that highlights the main benefit and a call to action.
    3. Tone: Professional yet persuasive, suitable for "${category}".

    Current Title: "${currentTitle}"

    Respond ONLY with a JSON object containing "title" and "description".`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
            },
            required: ["title", "description"],
        },
      },
    });
    
    const text = response.text;
    if (!text) {
        throw new Error("No text returned from Gemini API.");
    }

    return JSON.parse(text.trim());
  } catch (error) {
    console.error("Error suggesting content rewrite:", error);
    return { title: "Error generating title.", description: "Error generating description." };
  }
};

export const classifyOpportunities = async (opportunities: Opportunity[]) => {
  try {
    const prompt = `
      You are a senior ecommerce product manager analyzing brand health issues.
      Classify each of the following opportunities based on 'revenue impact' (High/Low) and 'ease of fix' (Easy/Hard).
      An 'Easy' fix is something that can be done quickly without significant resources (e.g., updating a product title).
      A 'Hard' fix requires coordination, budget, or significant effort (e.g., resolving a supply chain issue).
      A 'High' impact issue directly and significantly affects revenue (e.g., major OOS on a top seller).
      A 'Low' impact issue is less critical or affects lower-volume products.

      Here are the opportunities:
      ${JSON.stringify(opportunities.map(({id, description}) => ({id, description})), null, 2)}

      Respond ONLY with a valid JSON array of objects, where each object has "id", "revenueImpact", and "easeOfFix".
      Example format: [{"id": "1", "revenueImpact": "High", "easeOfFix": "Easy"}]
    `;
    
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        id: { type: Type.STRING },
                        revenueImpact: { type: Type.STRING, enum: ["High", "Low"] },
                        easeOfFix: { type: Type.STRING, enum: ["Easy", "Hard"] },
                    },
                    required: ["id", "revenueImpact", "easeOfFix"],
                },
            },
        },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText);
  } catch (error) {
    console.error("Error classifying opportunities:", error);
    return [];
  }
};

export interface PoachingCampaign {
  platform: string;
  keywords: string[];
  emergencyBudget: string;
  recommendedProducts: string[];
  rationale: string;
  cities?: string[];
}

export const generatePoachingCampaign = async (platform: string, cluster: string, competitor: string): Promise<PoachingCampaign> => {
  try {
    const isBlinkit = platform.toLowerCase().includes('blinkit');
    const prompt = `
      You are a senior media buyer for a major brand in India. 
      A competitor (${competitor}) is currently dominating the "${cluster}" category on ${platform}.
      
      Create a "Competition Poaching Campaign" (Conquesting) brief.
      Provide:
      1. A list of 5 high-intent keywords to target (including competitor brand terms if appropriate).
      2. An recommended "Emergency Budget" for a 48-hour blitz in INR (Indian Rupees).
      3. 3 types of products or specific SKU categories from our portfolio that should be pushed to counter them.
      4. A brief 1-sentence rationale for this strategy.
      ${isBlinkit ? '5. A list of 3-5 key Indian cities where this campaign should be prioritized (e.g., Mumbai, Delhi, Bangalore).' : ''}

      Respond ONLY with a valid JSON object in this format:
      {
        "platform": "${platform}",
        "keywords": ["kw1", "kw2", ...],
        "emergencyBudget": "₹X,XX,XXX",
        "recommendedProducts": ["prod1", "prod2", ...],
        "rationale": "..."${isBlinkit ? ',\n        "cities": ["City1", "City2", ...]' : ''}
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            platform: { type: Type.STRING },
            keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            emergencyBudget: { type: Type.STRING },
            recommendedProducts: { type: Type.ARRAY, items: { type: Type.STRING } },
            rationale: { type: Type.STRING },
            cities: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["platform", "keywords", "emergencyBudget", "recommendedProducts", "rationale"],
        },
      },
    });

    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Error generating poaching campaign:", error);
    const isBlinkitFallback = platform.toLowerCase().includes('blinkit');
    return {
      platform,
      keywords: ["Competitor Name", "Category Leader", "Top Rated", "Best Value", "Premium Alternative"],
      emergencyBudget: "₹5,00,000",
      recommendedProducts: ["Best Seller SKU", "New Launch", "Value Pack"],
      rationale: "Defensive conquesting to regain share of voice from dominant competitor.",
      cities: isBlinkitFallback ? ["Mumbai", "Delhi", "Bangalore"] : undefined
    };
  }
};
